package b0;

import java.util.Random;

public final class c extends a {
    public final b b = new ThreadLocal();

    public final Random a() {
        Object obj = this.b.get();
        a0.c.d(obj, "implStorage.get()");
        return (Random) obj;
    }
}
