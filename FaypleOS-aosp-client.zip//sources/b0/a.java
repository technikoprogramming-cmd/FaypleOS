package b0;

import V.b;
import java.util.Random;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final a f694a = b.f253a.a();

    public abstract Random a();

    public final int b() {
        return a().nextInt(2147418112);
    }
}
