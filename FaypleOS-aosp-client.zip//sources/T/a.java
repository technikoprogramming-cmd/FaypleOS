package T;

import a0.c;
import java.io.Serializable;

public final class a implements Serializable {

    /* renamed from: a  reason: collision with root package name */
    public final Object f241a;
    public final Object b;

    public a(Object obj, Object obj2) {
        this.f241a = obj;
        this.b = obj2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (c.a(this.f241a, aVar.f241a) && c.a(this.b, aVar.b)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i2;
        int i3 = 0;
        Object obj = this.f241a;
        if (obj == null) {
            i2 = 0;
        } else {
            i2 = obj.hashCode();
        }
        int i4 = i2 * 31;
        Object obj2 = this.b;
        if (obj2 != null) {
            i3 = obj2.hashCode();
        }
        return i4 + i3;
    }

    public final String toString() {
        return "(" + this.f241a + ", " + this.b + ')';
    }
}
