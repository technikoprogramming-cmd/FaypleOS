package T;

public final class c {
    public static final c b = new c(0);

    /* renamed from: c  reason: collision with root package name */
    public static final c f244c = new c(1);

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f245a;

    public /* synthetic */ c(int i2) {
        this.f245a = i2;
    }

    public String toString() {
        switch (this.f245a) {
            case 1:
                return "kotlin.Unit";
            default:
                return super.toString();
        }
    }
}
