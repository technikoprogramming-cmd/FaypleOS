package T;

import a0.c;
import androidx.activity.n;
import java.io.Serializable;

public final class b implements Serializable {

    /* renamed from: a  reason: collision with root package name */
    public n f242a;
    public volatile Object b = c.b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f243c = this;

    public b(n nVar) {
        this.f242a = nVar;
    }

    public final Object a() {
        Object obj;
        Object obj2 = this.b;
        c cVar = c.b;
        if (obj2 != cVar) {
            return obj2;
        }
        synchronized (this.f243c) {
            obj = this.b;
            if (obj == cVar) {
                n nVar = this.f242a;
                c.b(nVar);
                obj = nVar.a();
                this.b = obj;
                this.f242a = null;
            }
        }
        return obj;
    }

    public final String toString() {
        if (this.b != c.b) {
            return String.valueOf(a());
        }
        return "Lazy value not initialized yet.";
    }
}
