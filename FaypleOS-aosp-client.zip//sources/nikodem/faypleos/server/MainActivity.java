package nikodem.faypleos.server;

import C.j;
import D.b;
import F.d;
import L.a;
import L.e;
import R.h;
import S.g;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import e.C0020h;
import e.C0021i;
import f0.i;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.WeakHashMap;
import y.A;
import y.K;

public class MainActivity extends C0021i {

    /* renamed from: G  reason: collision with root package name */
    public static boolean f1441G = false;

    /* renamed from: A  reason: collision with root package name */
    public SharedPreferences f1442A = null;

    /* renamed from: B  reason: collision with root package name */
    public boolean f1443B = false;

    /* renamed from: C  reason: collision with root package name */
    public g f1444C;

    /* renamed from: D  reason: collision with root package name */
    public GeolocationPermissions.Callback f1445D = null;

    /* renamed from: E  reason: collision with root package name */
    public String f1446E = null;

    /* renamed from: F  reason: collision with root package name */
    public PermissionRequest f1447F;

    /* renamed from: x  reason: collision with root package name */
    public WebView f1448x;

    /* renamed from: y  reason: collision with root package name */
    public ValueCallback f1449y;

    /* renamed from: z  reason: collision with root package name */
    public String f1450z;

    public MainActivity() {
        ((e) this.f285e.f118c).e("androidx:appcompat", new a(this));
        f(new C0020h(this));
    }

    public static File n(MainActivity mainActivity) {
        String format = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        return File.createTempFile("JPEG_" + format + "_", ".jpg", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
    }

    public static String o(MainActivity mainActivity) {
        Point point = new Point();
        ((WindowManager) mainActivity.getSystemService("window")).getDefaultDisplay().getRealSize(point);
        return point.x + "x" + point.y;
    }

    public final void onActivityResult(int i2, int i3, Intent intent) {
        Uri[] uriArr;
        if (i2 != 1 || this.f1449y == null) {
            super.onActivityResult(i2, i3, intent);
            return;
        }
        if (i3 == -1) {
            if (intent == null) {
                String str = this.f1450z;
                if (str != null) {
                    uriArr = new Uri[]{Uri.parse(str)};
                    this.f1449y.onReceiveValue(uriArr);
                    this.f1449y = null;
                }
            } else {
                String dataString = intent.getDataString();
                if (dataString != null) {
                    uriArr = new Uri[]{Uri.parse(dataString)};
                    this.f1449y.onReceiveValue(uriArr);
                    this.f1449y = null;
                }
            }
        }
        uriArr = null;
        this.f1449y.onReceiveValue(uriArr);
        this.f1449y = null;
    }

    /* JADX WARNING: type inference failed for: r12v8, types: [java.lang.Object, S.g] */
    /* JADX WARNING: type inference failed for: r1v16, types: [java.lang.Object, y.p] */
    /* JADX WARNING: type inference failed for: r0v2, types: [f0.c, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r1v22, types: [java.lang.Object, android.view.View$OnApplyWindowInsetsListener] */
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        getWindow().addFlags(128);
        ((PowerManager) getSystemService("power")).newWakeLock(1, "MyApp::MyWakelockTag").acquire();
        setRequestedOrientation(-1);
        ? obj = new Object();
        obj.f218d = new Handler();
        obj.f219e = true;
        obj.f221h = "https://webintoapp.com/ads/";
        obj.f222i = "true";
        obj.f223j = "true";
        obj.f224k = "banner ";
        obj.f225l = "";
        obj.f226m = "true";
        obj.f227n = "";
        obj.f228o = "";
        obj.f229p = "";
        obj.f230q = "live";
        obj.f231r = "";
        obj.f232s = Boolean.FALSE;
        obj.f = 3000;
        obj.f220g = 60000;
        obj.b = this;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (defaultSharedPreferences.getString("installkey", (String) null) == null) {
            Random random = new Random();
            StringBuilder sb = new StringBuilder(32);
            for (int i2 = 0; i2 < 32; i2++) {
                sb.append("0123456789qwertyuiopasdfghjklzxcvbnm".charAt(random.nextInt(36)));
            }
            defaultSharedPreferences.edit().putString("installkey", sb.toString()).apply();
        }
        String string = defaultSharedPreferences.getString("installkey", (String) null);
        obj.f228o = string;
        obj.f227n = "1045960";
        obj.f221h = "https://ads.webintoapp.com/ads/";
        D.g.C(obj.b).a(new h(0, "https://ads.webintoapp.com/ads/ads-start.json?ai=1045960&ik=" + string, new S.e(obj), new d(9)));
        this.f1444C = obj;
        WebView webView = (WebView) findViewById(R.id.activity_splash_webview);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("file:///android_asset/htmlapp/helpers/loading.html");
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener(new Object());
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController d2 = getWindow().getInsetsController();
            if (d2 != null) {
                d2.setSystemBarsAppearance(0, 8);
            }
        }
        this.f1442A = getSharedPreferences("nikodem.faypleos.server", 0);
        this.f1448x = (WebView) findViewById(R.id.activity_main_webview);
        View findViewById = findViewById(R.id.container);
        ? obj2 = new Object();
        WeakHashMap weakHashMap = K.f1547a;
        A.u(findViewById, obj2);
        this.f1448x.setWebChromeClient(new f0.h(this));
        this.f1448x.getSettings().setDomStorageEnabled(true);
        this.f1448x.setDownloadListener(new i(this));
        this.f1448x.setWebViewClient(new f0.g(1, this));
        WebView webView2 = this.f1448x;
        WebSettings settings = webView2.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setSupportZoom(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(System.getProperty("http.agent"));
        settings.setCacheMode(1);
        ? obj3 = new Object();
        obj3.f895a = this;
        webView2.addJavascriptInterface(obj3, "Android");
        this.f1448x.loadUrl("file:///android_asset/htmlapp/root/index.html");
    }

    public final void onDestroy() {
        throw null;
    }

    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 0 || i2 != 4) {
            return super.onKeyDown(i2, keyEvent);
        }
        if (this.f1443B) {
            finish();
        }
        if (this.f1448x.canGoBack()) {
            this.f1448x.goBack();
            return true;
        }
        g gVar = this.f1444C;
        boolean equals = gVar.f223j.equals("false");
        MainActivity mainActivity = gVar.b;
        if (equals) {
            mainActivity.finish();
        }
        j jVar = new j(8);
        jVar.b = new S.e(gVar);
        D.g.C(mainActivity).a(new h(0, (gVar.f221h + "ads-exit.json") + "?ai=" + gVar.f227n + "&ik=" + gVar.f228o + "&si=" + gVar.f229p, new G.a(jVar, mainActivity, false), new d(13)));
        return true;
    }

    public final void onPause() {
        super.onPause();
        g gVar = this.f1444C;
        gVar.f218d.removeCallbacks(gVar.f216a);
    }

    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i2, strArr, iArr);
        if (iArr.length > 0 && iArr[0] == 0) {
            if (i2 == 100) {
                GeolocationPermissions.Callback callback = this.f1445D;
                if (callback != null) {
                    callback.invoke(this.f1446E, true, true);
                }
            } else if (i2 == 1001) {
                if (o.e.a(this, "android.permission.RECORD_AUDIO") == 0) {
                    PermissionRequest permissionRequest = this.f1447F;
                    permissionRequest.grant(permissionRequest.getResources());
                } else {
                    o.e.g(this, new String[]{"android.permission.RECORD_AUDIO"}, 106);
                }
            } else if (i2 == 1002) {
                PermissionRequest permissionRequest2 = this.f1447F;
                permissionRequest2.grant(permissionRequest2.getResources());
            }
            this.f1448x.reload();
        }
    }

    public final void onResume() {
        super.onResume();
        if (this.f1442A.getBoolean("firstrun", true)) {
            new Thread(new b(4, (Object) this)).start();
            g gVar = this.f1444C;
            gVar.f218d.removeCallbacks(gVar.f216a);
        }
    }
}
