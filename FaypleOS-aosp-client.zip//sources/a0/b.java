package a0;

import Z.c;
import Z.d;
import Z.e;
import Z.f;
import Z.g;
import Z.h;
import Z.i;
import Z.j;
import Z.k;
import Z.l;
import Z.m;
import Z.n;
import Z.o;
import Z.p;
import Z.q;
import Z.r;
import Z.s;
import Z.t;
import Z.u;
import Z.v;
import Z.w;
import d0.a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class b implements a, a {
    public static final Map b;

    /* renamed from: a  reason: collision with root package name */
    public final Class f256a;

    static {
        List asList = Arrays.asList(new Class[]{Z.a.class, l.class, p.class, q.class, r.class, s.class, t.class, u.class, v.class, w.class, Z.b.class, c.class, d.class, e.class, f.class, g.class, h.class, i.class, j.class, k.class, m.class, n.class, o.class});
        c.d(asList, "asList(this)");
        ArrayList arrayList = new ArrayList(asList.size());
        int i2 = 0;
        for (Object next : asList) {
            int i3 = i2 + 1;
            if (i2 >= 0) {
                arrayList.add(new T.a((Class) next, Integer.valueOf(i2)));
                i2 = i3;
            } else {
                throw new ArithmeticException("Index overflow has happened.");
            }
        }
        b = U.g.V(arrayList);
        HashMap hashMap = new HashMap();
        hashMap.put("boolean", "kotlin.Boolean");
        hashMap.put("char", "kotlin.Char");
        hashMap.put("byte", "kotlin.Byte");
        hashMap.put("short", "kotlin.Short");
        hashMap.put("int", "kotlin.Int");
        hashMap.put("float", "kotlin.Float");
        hashMap.put("long", "kotlin.Long");
        hashMap.put("double", "kotlin.Double");
        HashMap hashMap2 = new HashMap();
        hashMap2.put("java.lang.Boolean", "kotlin.Boolean");
        hashMap2.put("java.lang.Character", "kotlin.Char");
        hashMap2.put("java.lang.Byte", "kotlin.Byte");
        hashMap2.put("java.lang.Short", "kotlin.Short");
        hashMap2.put("java.lang.Integer", "kotlin.Int");
        hashMap2.put("java.lang.Float", "kotlin.Float");
        hashMap2.put("java.lang.Long", "kotlin.Long");
        hashMap2.put("java.lang.Double", "kotlin.Double");
        HashMap hashMap3 = new HashMap();
        hashMap3.put("java.lang.Object", "kotlin.Any");
        hashMap3.put("java.lang.String", "kotlin.String");
        hashMap3.put("java.lang.CharSequence", "kotlin.CharSequence");
        hashMap3.put("java.lang.Throwable", "kotlin.Throwable");
        hashMap3.put("java.lang.Cloneable", "kotlin.Cloneable");
        hashMap3.put("java.lang.Number", "kotlin.Number");
        hashMap3.put("java.lang.Comparable", "kotlin.Comparable");
        hashMap3.put("java.lang.Enum", "kotlin.Enum");
        hashMap3.put("java.lang.annotation.Annotation", "kotlin.Annotation");
        hashMap3.put("java.lang.Iterable", "kotlin.collections.Iterable");
        hashMap3.put("java.util.Iterator", "kotlin.collections.Iterator");
        hashMap3.put("java.util.Collection", "kotlin.collections.Collection");
        hashMap3.put("java.util.List", "kotlin.collections.List");
        hashMap3.put("java.util.Set", "kotlin.collections.Set");
        hashMap3.put("java.util.ListIterator", "kotlin.collections.ListIterator");
        hashMap3.put("java.util.Map", "kotlin.collections.Map");
        hashMap3.put("java.util.Map$Entry", "kotlin.collections.Map.Entry");
        hashMap3.put("kotlin.jvm.internal.StringCompanionObject", "kotlin.String.Companion");
        hashMap3.put("kotlin.jvm.internal.EnumCompanionObject", "kotlin.Enum.Companion");
        hashMap3.putAll(hashMap);
        hashMap3.putAll(hashMap2);
        Collection<String> values = hashMap.values();
        c.d(values, "primitiveFqNames.values");
        for (String str : values) {
            StringBuilder sb = new StringBuilder("kotlin.jvm.internal.");
            c.d(str, "kotlinName");
            sb.append(e0.g.V(str));
            sb.append("CompanionObject");
            hashMap3.put(sb.toString(), str.concat(".Companion"));
        }
        for (Map.Entry entry : b.entrySet()) {
            int intValue = ((Number) entry.getValue()).intValue();
            String name = ((Class) entry.getKey()).getName();
            hashMap3.put(name, "kotlin.Function" + intValue);
        }
        int size = hashMap3.size();
        if (size >= 0) {
            if (size < 3) {
                size++;
            } else if (size < 1073741824) {
                size = (int) ((((float) size) / 0.75f) + 1.0f);
            } else {
                size = Integer.MAX_VALUE;
            }
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(size);
        for (Map.Entry entry2 : hashMap3.entrySet()) {
            linkedHashMap.put(entry2.getKey(), e0.g.V((String) entry2.getValue()));
        }
    }

    public b(Class cls) {
        this.f256a = cls;
    }

    public final Class a() {
        return this.f256a;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b) || !D.g.v(this).equals(D.g.v((a) obj))) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return D.g.v(this).hashCode();
    }

    public final String toString() {
        return this.f256a.toString() + " (Kotlin reflection is not available)";
    }
}
