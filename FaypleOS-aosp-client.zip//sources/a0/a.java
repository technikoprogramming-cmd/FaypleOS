package a0;

public interface a {
    Class a();
}
