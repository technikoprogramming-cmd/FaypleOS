package a0;

import java.io.Serializable;

public abstract class d implements Serializable {
    public final String toString() {
        f.f258a.getClass();
        String obj = getClass().getGenericInterfaces()[0].toString();
        if (obj.startsWith("kotlin.jvm.functions.")) {
            obj = obj.substring(21);
        }
        c.d(obj, "renderLambdaToString(this)");
        return obj;
    }
}
