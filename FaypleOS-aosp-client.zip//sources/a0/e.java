package a0;

import androidx.activity.t;

public final class e implements a {
    public final Class a() {
        return t.class;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof e)) {
            return false;
        }
        ((e) obj).getClass();
        Class<t> cls = t.class;
        if (cls.equals(cls)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return t.class.hashCode();
    }

    public final String toString() {
        return t.class.toString() + " (Kotlin reflection is not available)";
    }
}
