package V;

import b0.c;

public class a {
    public b0.a a() {
        return new c();
    }
}
