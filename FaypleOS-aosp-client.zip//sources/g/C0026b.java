package g;

/* renamed from: g.b  reason: case insensitive filesystem */
public interface C0026b {
}
