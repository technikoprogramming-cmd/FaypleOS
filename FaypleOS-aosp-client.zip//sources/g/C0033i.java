package g;

import i.e1;
import z.C0190i;

/* renamed from: g.i  reason: case insensitive filesystem */
public final class C0033i extends C0190i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f948a = 0;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public int f949c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Object f950d;

    public C0033i(C0034j jVar) {
        this.f950d = jVar;
        this.b = false;
        this.f949c = 0;
    }

    public final void a() {
        switch (this.f948a) {
            case 0:
                int i2 = this.f949c + 1;
                this.f949c = i2;
                C0034j jVar = (C0034j) this.f950d;
                if (i2 == jVar.f951a.size()) {
                    C0190i iVar = jVar.f953d;
                    if (iVar != null) {
                        iVar.a();
                    }
                    this.f949c = 0;
                    this.b = false;
                    jVar.f954e = false;
                    return;
                }
                return;
            default:
                if (!this.b) {
                    ((e1) this.f950d).f1229a.setVisibility(this.f949c);
                    return;
                }
                return;
        }
    }

    public void b() {
        switch (this.f948a) {
            case 1:
                this.b = true;
                return;
            default:
                return;
        }
    }

    public final void c() {
        switch (this.f948a) {
            case 0:
                if (!this.b) {
                    this.b = true;
                    C0190i iVar = ((C0034j) this.f950d).f953d;
                    if (iVar != null) {
                        iVar.c();
                        return;
                    }
                    return;
                }
                return;
            default:
                ((e1) this.f950d).f1229a.setVisibility(0);
                return;
        }
    }

    public C0033i(e1 e1Var, int i2) {
        this.f950d = e1Var;
        this.f949c = i2;
        this.b = false;
    }
}
