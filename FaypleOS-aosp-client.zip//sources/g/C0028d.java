package g;

import G.a;
import Q.t;
import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import h.l;
import h.n;
import i.C0069l;
import java.lang.ref.WeakReference;

/* renamed from: g.d  reason: case insensitive filesystem */
public final class C0028d extends C0025a implements l {

    /* renamed from: c  reason: collision with root package name */
    public Context f907c;

    /* renamed from: d  reason: collision with root package name */
    public ActionBarContextView f908d;

    /* renamed from: e  reason: collision with root package name */
    public a f909e;
    public WeakReference f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f910g;

    /* renamed from: h  reason: collision with root package name */
    public n f911h;

    public final void a() {
        if (!this.f910g) {
            this.f910g = true;
            this.f909e.e(this);
        }
    }

    public final View b() {
        WeakReference weakReference = this.f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    public final n c() {
        return this.f911h;
    }

    public final MenuInflater d() {
        return new C0032h(this.f908d.getContext());
    }

    public final CharSequence e() {
        return this.f908d.getSubtitle();
    }

    public final CharSequence f() {
        return this.f908d.getTitle();
    }

    public final void g(n nVar) {
        i();
        C0069l lVar = this.f908d.f353d;
        if (lVar != null) {
            lVar.l();
        }
    }

    public final boolean h(n nVar, MenuItem menuItem) {
        return ((t) this.f909e.f57a).c(this, menuItem);
    }

    public final void i() {
        this.f909e.g(this, this.f911h);
    }

    public final boolean j() {
        return this.f908d.f367s;
    }

    public final void k(View view) {
        WeakReference weakReference;
        this.f908d.setCustomView(view);
        if (view != null) {
            weakReference = new WeakReference(view);
        } else {
            weakReference = null;
        }
        this.f = weakReference;
    }

    public final void l(int i2) {
        m(this.f907c.getString(i2));
    }

    public final void m(CharSequence charSequence) {
        this.f908d.setSubtitle(charSequence);
    }

    public final void n(int i2) {
        o(this.f907c.getString(i2));
    }

    public final void o(CharSequence charSequence) {
        this.f908d.setTitle(charSequence);
    }

    public final void p(boolean z2) {
        this.b = z2;
        this.f908d.setTitleOptional(z2);
    }
}
