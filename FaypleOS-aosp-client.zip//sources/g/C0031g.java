package g;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import h.p;
import h.q;
import h.u;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import t.C0147a;
import y.C0168l;

/* renamed from: g.g  reason: case insensitive filesystem */
public final class C0031g {

    /* renamed from: A  reason: collision with root package name */
    public CharSequence f915A;

    /* renamed from: B  reason: collision with root package name */
    public CharSequence f916B;

    /* renamed from: C  reason: collision with root package name */
    public ColorStateList f917C = null;

    /* renamed from: D  reason: collision with root package name */
    public PorterDuff.Mode f918D = null;

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ C0032h f919E;

    /* renamed from: a  reason: collision with root package name */
    public final Menu f920a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f921c;

    /* renamed from: d  reason: collision with root package name */
    public int f922d;

    /* renamed from: e  reason: collision with root package name */
    public int f923e;
    public boolean f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f924g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f925h;

    /* renamed from: i  reason: collision with root package name */
    public int f926i;

    /* renamed from: j  reason: collision with root package name */
    public int f927j;

    /* renamed from: k  reason: collision with root package name */
    public CharSequence f928k;

    /* renamed from: l  reason: collision with root package name */
    public CharSequence f929l;

    /* renamed from: m  reason: collision with root package name */
    public int f930m;

    /* renamed from: n  reason: collision with root package name */
    public char f931n;

    /* renamed from: o  reason: collision with root package name */
    public int f932o;

    /* renamed from: p  reason: collision with root package name */
    public char f933p;

    /* renamed from: q  reason: collision with root package name */
    public int f934q;

    /* renamed from: r  reason: collision with root package name */
    public int f935r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f936s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f937t;

    /* renamed from: u  reason: collision with root package name */
    public boolean f938u;

    /* renamed from: v  reason: collision with root package name */
    public int f939v;

    /* renamed from: w  reason: collision with root package name */
    public int f940w;

    /* renamed from: x  reason: collision with root package name */
    public String f941x;

    /* renamed from: y  reason: collision with root package name */
    public String f942y;

    /* renamed from: z  reason: collision with root package name */
    public q f943z;

    public C0031g(C0032h hVar, Menu menu) {
        this.f919E = hVar;
        this.f920a = menu;
        this.b = 0;
        this.f921c = 0;
        this.f922d = 0;
        this.f923e = 0;
        this.f = true;
        this.f924g = true;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f919E.f946c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e2) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
            return null;
        }
    }

    /* JADX WARNING: type inference failed for: r0v33, types: [android.view.MenuItem$OnMenuItemClickListener, java.lang.Object, g.f] */
    public final void b(MenuItem menuItem) {
        boolean z2;
        MenuItem enabled = menuItem.setChecked(this.f936s).setVisible(this.f937t).setEnabled(this.f938u);
        boolean z3 = false;
        if (this.f935r >= 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        enabled.setCheckable(z2).setTitleCondensed(this.f929l).setIcon(this.f930m);
        int i2 = this.f939v;
        if (i2 >= 0) {
            menuItem.setShowAsAction(i2);
        }
        String str = this.f942y;
        C0032h hVar = this.f919E;
        if (str != null) {
            if (!hVar.f946c.isRestricted()) {
                if (hVar.f947d == null) {
                    hVar.f947d = C0032h.a(hVar.f946c);
                }
                Object obj = hVar.f947d;
                String str2 = this.f942y;
                ? obj2 = new Object();
                obj2.f914a = obj;
                Class<?> cls = obj.getClass();
                try {
                    obj2.b = cls.getMethod(str2, C0030f.f913c);
                    menuItem.setOnMenuItemClickListener(obj2);
                } catch (Exception e2) {
                    InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                    inflateException.initCause(e2);
                    throw inflateException;
                }
            } else {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
        }
        if (this.f935r >= 2) {
            if (menuItem instanceof p) {
                p pVar = (p) menuItem;
                pVar.f1079x = (pVar.f1079x & -5) | 4;
            } else if (menuItem instanceof u) {
                u uVar = (u) menuItem;
                try {
                    Method method = uVar.f1088d;
                    C0147a aVar = uVar.f1087c;
                    if (method == null) {
                        uVar.f1088d = aVar.getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
                    }
                    uVar.f1088d.invoke(aVar, new Object[]{Boolean.TRUE});
                } catch (Exception e3) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e3);
                }
            }
        }
        String str3 = this.f941x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0032h.f944e, hVar.f945a));
            z3 = true;
        }
        int i3 = this.f940w;
        if (i3 > 0) {
            if (!z3) {
                menuItem.setActionView(i3);
            } else {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            }
        }
        q qVar = this.f943z;
        if (qVar != null) {
            if (menuItem instanceof C0147a) {
                ((C0147a) menuItem).b(qVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.f915A;
        boolean z4 = menuItem instanceof C0147a;
        if (z4) {
            ((C0147a) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0168l.h(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.f916B;
        if (z4) {
            ((C0147a) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0168l.m(menuItem, charSequence2);
        }
        char c2 = this.f931n;
        int i4 = this.f932o;
        if (z4) {
            ((C0147a) menuItem).setAlphabeticShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0168l.g(menuItem, c2, i4);
        }
        char c3 = this.f933p;
        int i5 = this.f934q;
        if (z4) {
            ((C0147a) menuItem).setNumericShortcut(c3, i5);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0168l.k(menuItem, c3, i5);
        }
        PorterDuff.Mode mode = this.f918D;
        if (mode != null) {
            if (z4) {
                ((C0147a) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                C0168l.j(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.f917C;
        if (colorStateList == null) {
            return;
        }
        if (z4) {
            ((C0147a) menuItem).setIconTintList(colorStateList);
        } else if (Build.VERSION.SDK_INT >= 26) {
            C0168l.i(menuItem, colorStateList);
        }
    }
}
