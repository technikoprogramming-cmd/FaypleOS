package i;

import android.view.Window;

/* renamed from: i.l0  reason: case insensitive filesystem */
public interface C0070l0 {
    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
