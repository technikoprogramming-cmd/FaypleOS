package i;

import C.j;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.PopupWindow;
import h.n;
import h.p;
import java.lang.reflect.Method;

public final class L0 extends G0 implements H0 {

    /* renamed from: C  reason: collision with root package name */
    public static final Method f1155C;

    /* renamed from: B  reason: collision with root package name */
    public j f1156B;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f1155C = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[]{Boolean.TYPE});
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public final C0085t0 o(Context context, boolean z2) {
        K0 k0 = new K0(context, z2);
        k0.setHoverListener(this);
        return k0;
    }

    public final void r(n nVar, p pVar) {
        j jVar = this.f1156B;
        if (jVar != null) {
            jVar.r(nVar, pVar);
        }
    }

    public final void t(n nVar, p pVar) {
        j jVar = this.f1156B;
        if (jVar != null) {
            jVar.t(nVar, pVar);
        }
    }
}
