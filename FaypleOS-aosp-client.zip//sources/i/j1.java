package i;

public abstract class j1 extends O0 {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f1275a = 0;
}
