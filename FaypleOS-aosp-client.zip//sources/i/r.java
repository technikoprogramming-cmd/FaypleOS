package i;

import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import nikodem.faypleos.server.R;

public final class r extends Button {

    /* renamed from: a  reason: collision with root package name */
    public final C0079q f1315a;
    public final Z b;

    /* renamed from: c  reason: collision with root package name */
    public C0094y f1316c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public r(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyle);
        T0.a(context);
        S0.a(this, getContext());
        C0079q qVar = new C0079q(this);
        this.f1315a = qVar;
        qVar.d(attributeSet, R.attr.buttonStyle);
        Z z2 = new Z(this);
        this.b = z2;
        z2.f(attributeSet, R.attr.buttonStyle);
        z2.b();
        getEmojiTextViewHelper().a(attributeSet, R.attr.buttonStyle);
    }

    private C0094y getEmojiTextViewHelper() {
        if (this.f1316c == null) {
            this.f1316c = new C0094y(this);
        }
        return this.f1316c;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            qVar.a();
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (m1.f1299c) {
            return super.getAutoSizeMaxTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1206i.f1261e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (m1.f1299c) {
            return super.getAutoSizeMinTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1206i.f1260d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (m1.f1299c) {
            return super.getAutoSizeStepGranularity();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1206i.f1259c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (m1.f1299c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return z2.f1206i.f;
        }
        return new int[0];
    }

    public int getAutoSizeTextType() {
        if (!m1.f1299c) {
            Z z2 = this.b;
            if (z2 != null) {
                return z2.f1206i.f1258a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        Z z3 = this.b;
        if (z3 != null && !m1.f1299c) {
            z3.f1206i.a();
        }
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        Z z2 = this.b;
        if (z2 != null && !m1.f1299c) {
            C0064i0 i0Var = z2.f1206i;
            if (i0Var.f()) {
                i0Var.a();
            }
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (m1.f1299c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.i(i2, i3, i4, i5);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (m1.f1299c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.j(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (m1.f1299c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.k(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((g) getEmojiTextViewHelper().b.b).u(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        Z z3 = this.b;
        if (z3 != null) {
            z3.f1200a.setAllCaps(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q qVar = this.f1315a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.b;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.b;
        z2.m(mode);
        z2.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Z z2 = this.b;
        if (z2 != null) {
            z2.g(context, i2);
        }
    }

    public final void setTextSize(int i2, float f) {
        boolean z2 = m1.f1299c;
        if (z2) {
            super.setTextSize(i2, f);
            return;
        }
        Z z3 = this.b;
        if (z3 != null && !z2) {
            C0064i0 i0Var = z3.f1206i;
            if (!i0Var.f()) {
                i0Var.g(i2, f);
            }
        }
    }
}
