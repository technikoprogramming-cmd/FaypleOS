package i;

import C.j;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import h.B;
import h.C0036A;
import h.F;
import h.n;
import h.p;
import h.q;
import h.v;
import h.y;
import h.z;
import java.util.ArrayList;
import nikodem.faypleos.server.R;

/* renamed from: i.l  reason: case insensitive filesystem */
public final class C0069l implements z {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1277a;
    public Context b;

    /* renamed from: c  reason: collision with root package name */
    public n f1278c;

    /* renamed from: d  reason: collision with root package name */
    public final LayoutInflater f1279d;

    /* renamed from: e  reason: collision with root package name */
    public y f1280e;
    public final int f = R.layout.abc_action_menu_layout;

    /* renamed from: g  reason: collision with root package name */
    public final int f1281g = R.layout.abc_action_menu_item_layout;

    /* renamed from: h  reason: collision with root package name */
    public B f1282h;

    /* renamed from: i  reason: collision with root package name */
    public C0067k f1283i;

    /* renamed from: j  reason: collision with root package name */
    public Drawable f1284j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1285k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f1286l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f1287m;

    /* renamed from: n  reason: collision with root package name */
    public int f1288n;

    /* renamed from: o  reason: collision with root package name */
    public int f1289o;

    /* renamed from: p  reason: collision with root package name */
    public int f1290p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f1291q;

    /* renamed from: r  reason: collision with root package name */
    public final SparseBooleanArray f1292r = new SparseBooleanArray();

    /* renamed from: s  reason: collision with root package name */
    public C0061h f1293s;

    /* renamed from: t  reason: collision with root package name */
    public C0061h f1294t;

    /* renamed from: u  reason: collision with root package name */
    public C0065j f1295u;

    /* renamed from: v  reason: collision with root package name */
    public C0063i f1296v;

    /* renamed from: w  reason: collision with root package name */
    public final j f1297w = new j(17, (Object) this);

    public C0069l(Context context) {
        this.f1277a = context;
        this.f1279d = LayoutInflater.from(context);
    }

    public final View a(p pVar, View view, ViewGroup viewGroup) {
        C0036A a2;
        View actionView = pVar.getActionView();
        int i2 = 0;
        if (actionView == null || pVar.e()) {
            if (view instanceof C0036A) {
                a2 = (C0036A) view;
            } else {
                a2 = (C0036A) this.f1279d.inflate(this.f1281g, viewGroup, false);
            }
            a2.c(pVar);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) a2;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f1282h);
            if (this.f1296v == null) {
                this.f1296v = new C0063i(this);
            }
            actionMenuItemView.setPopupCallback(this.f1296v);
            actionView = (View) a2;
        }
        if (pVar.f1057C) {
            i2 = 8;
        }
        actionView.setVisibility(i2);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof C0073n)) {
            actionView.setLayoutParams(ActionMenuView.j(layoutParams));
        }
        return actionView;
    }

    public final void b(n nVar, boolean z2) {
        f();
        C0061h hVar = this.f1294t;
        if (hVar != null && hVar.b()) {
            hVar.f1097i.dismiss();
        }
        y yVar = this.f1280e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    public final void c() {
        B b2;
        int i2;
        p pVar;
        ViewGroup viewGroup = (ViewGroup) this.f1282h;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (viewGroup != null) {
            n nVar = this.f1278c;
            if (nVar != null) {
                nVar.i();
                ArrayList l2 = this.f1278c.l();
                int size = l2.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    p pVar2 = (p) l2.get(i3);
                    if ((pVar2.f1079x & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i2);
                        if (childAt instanceof C0036A) {
                            pVar = ((C0036A) childAt).getItemData();
                        } else {
                            pVar = null;
                        }
                        View a2 = a(pVar2, childAt, viewGroup);
                        if (pVar2 != pVar) {
                            a2.setPressed(false);
                            a2.jumpDrawablesToCurrentState();
                        }
                        if (a2 != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) a2.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(a2);
                            }
                            ((ViewGroup) this.f1282h).addView(a2, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i2) == this.f1283i) {
                    i2++;
                } else {
                    viewGroup.removeViewAt(i2);
                }
            }
        }
        ((View) this.f1282h).requestLayout();
        n nVar2 = this.f1278c;
        if (nVar2 != null) {
            nVar2.i();
            ArrayList arrayList2 = nVar2.f1037i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                q qVar = ((p) arrayList2.get(i4)).f1055A;
            }
        }
        n nVar3 = this.f1278c;
        if (nVar3 != null) {
            nVar3.i();
            arrayList = nVar3.f1038j;
        }
        if (this.f1286l && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((p) arrayList.get(0)).f1057C;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f1283i == null) {
                this.f1283i = new C0067k(this, this.f1277a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f1283i.getParent();
            if (viewGroup3 != this.f1282h) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f1283i);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f1282h;
                C0067k kVar = this.f1283i;
                actionMenuView.getClass();
                C0073n i5 = ActionMenuView.i();
                i5.f1300a = true;
                actionMenuView.addView(kVar, i5);
            }
        } else {
            C0067k kVar2 = this.f1283i;
            if (kVar2 != null && kVar2.getParent() == (b2 = this.f1282h)) {
                ((ViewGroup) b2).removeView(this.f1283i);
            }
        }
        ((ActionMenuView) this.f1282h).setOverflowReserved(this.f1286l);
    }

    public final boolean d(p pVar) {
        return false;
    }

    public final void e(y yVar) {
        throw null;
    }

    public final boolean f() {
        B b2;
        C0065j jVar = this.f1295u;
        if (jVar == null || (b2 = this.f1282h) == null) {
            C0061h hVar = this.f1293s;
            if (hVar == null) {
                return false;
            }
            if (hVar.b()) {
                hVar.f1097i.dismiss();
            }
            return true;
        }
        ((View) b2).removeCallbacks(jVar);
        this.f1295u = null;
        return true;
    }

    public final void g(Context context, n nVar) {
        this.b = context;
        LayoutInflater.from(context);
        this.f1278c = nVar;
        Resources resources = context.getResources();
        if (!this.f1287m) {
            this.f1286l = true;
        }
        int i2 = 2;
        this.f1288n = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i2 = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i2 = 4;
        } else if (i3 >= 360) {
            i2 = 3;
        }
        this.f1290p = i2;
        int i5 = this.f1288n;
        if (this.f1286l) {
            if (this.f1283i == null) {
                C0067k kVar = new C0067k(this, this.f1277a);
                this.f1283i = kVar;
                if (this.f1285k) {
                    kVar.setImageDrawable(this.f1284j);
                    this.f1284j = null;
                    this.f1285k = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f1283i.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i5 -= this.f1283i.getMeasuredWidth();
        } else {
            this.f1283i = null;
        }
        this.f1289o = i5;
        float f2 = resources.getDisplayMetrics().density;
    }

    public final boolean h() {
        C0061h hVar = this.f1293s;
        if (hVar == null || !hVar.b()) {
            return false;
        }
        return true;
    }

    public final boolean i() {
        int i2;
        ArrayList arrayList;
        int i3;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        C0069l lVar = this;
        n nVar = lVar.f1278c;
        if (nVar != null) {
            arrayList = nVar.l();
            i2 = arrayList.size();
        } else {
            i2 = 0;
            arrayList = null;
        }
        int i4 = lVar.f1290p;
        int i5 = lVar.f1289o;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) lVar.f1282h;
        int i6 = 0;
        boolean z6 = false;
        int i7 = 0;
        int i8 = 0;
        while (true) {
            i3 = 2;
            z2 = true;
            if (i6 >= i2) {
                break;
            }
            p pVar = (p) arrayList.get(i6);
            int i9 = pVar.f1080y;
            if ((i9 & 2) == 2) {
                i7++;
            } else if ((i9 & 1) == 1) {
                i8++;
            } else {
                z6 = true;
            }
            if (lVar.f1291q && pVar.f1057C) {
                i4 = 0;
            }
            i6++;
        }
        if (lVar.f1286l && (z6 || i8 + i7 > i4)) {
            i4--;
        }
        int i10 = i4 - i7;
        SparseBooleanArray sparseBooleanArray = lVar.f1292r;
        sparseBooleanArray.clear();
        int i11 = 0;
        int i12 = 0;
        while (i11 < i2) {
            p pVar2 = (p) arrayList.get(i11);
            int i13 = pVar2.f1080y;
            if ((i13 & 2) == i3) {
                z3 = z2;
            } else {
                z3 = false;
            }
            int i14 = pVar2.b;
            if (z3) {
                View a2 = lVar.a(pVar2, (View) null, viewGroup);
                a2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = a2.getMeasuredWidth();
                i5 -= measuredWidth;
                if (i12 == 0) {
                    i12 = measuredWidth;
                }
                if (i14 != 0) {
                    sparseBooleanArray.put(i14, z2);
                }
                pVar2.f(z2);
            } else if ((i13 & true) == z2) {
                boolean z7 = sparseBooleanArray.get(i14);
                if ((i10 > 0 || z7) && i5 > 0) {
                    z4 = z2;
                } else {
                    z4 = false;
                }
                if (z4) {
                    View a3 = lVar.a(pVar2, (View) null, viewGroup);
                    a3.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = a3.getMeasuredWidth();
                    i5 -= measuredWidth2;
                    if (i12 == 0) {
                        i12 = measuredWidth2;
                    }
                    if (i5 + i12 > 0) {
                        z5 = true;
                    } else {
                        z5 = false;
                    }
                    z4 &= z5;
                }
                if (z4 && i14 != 0) {
                    sparseBooleanArray.put(i14, true);
                } else if (z7) {
                    sparseBooleanArray.put(i14, false);
                    int i15 = 0;
                    while (i15 < i11) {
                        p pVar3 = (p) arrayList.get(i15);
                        if (pVar3.b == i14) {
                            if ((pVar3.f1079x & 32) == 32) {
                                i10++;
                            }
                            pVar3.f(false);
                        }
                        i15++;
                    }
                }
                if (z4) {
                    i10--;
                }
                pVar2.f(z4);
            } else {
                pVar2.f(false);
                i11++;
                i3 = 2;
                lVar = this;
                z2 = true;
            }
            i11++;
            i3 = 2;
            lVar = this;
            z2 = true;
        }
        return z2;
    }

    public final boolean j(F f2) {
        boolean z2;
        if (f2.hasVisibleItems()) {
            F f3 = f2;
            while (true) {
                n nVar = f3.f974z;
                if (nVar == this.f1278c) {
                    break;
                }
                f3 = nVar;
            }
            ViewGroup viewGroup = (ViewGroup) this.f1282h;
            View view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        break;
                    }
                    View childAt = viewGroup.getChildAt(i2);
                    if ((childAt instanceof C0036A) && ((C0036A) childAt).getItemData() == f3.f973A) {
                        view = childAt;
                        break;
                    }
                    i2++;
                }
            }
            if (view != null) {
                f2.f973A.getClass();
                int size = f2.f.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        z2 = false;
                        break;
                    }
                    MenuItem item = f2.getItem(i3);
                    if (item.isVisible() && item.getIcon() != null) {
                        z2 = true;
                        break;
                    }
                    i3++;
                }
                C0061h hVar = new C0061h(this, this.b, f2, view);
                this.f1294t = hVar;
                hVar.f1095g = z2;
                v vVar = hVar.f1097i;
                if (vVar != null) {
                    vVar.o(z2);
                }
                C0061h hVar2 = this.f1294t;
                if (!hVar2.b()) {
                    if (hVar2.f1094e != null) {
                        hVar2.d(0, 0, false, false);
                    } else {
                        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
                    }
                }
                y yVar = this.f1280e;
                if (yVar != null) {
                    yVar.m(f2);
                }
                return true;
            }
        }
        return false;
    }

    public final boolean k(p pVar) {
        return false;
    }

    public final boolean l() {
        n nVar;
        if (!this.f1286l || h() || (nVar = this.f1278c) == null || this.f1282h == null || this.f1295u != null) {
            return false;
        }
        nVar.i();
        if (nVar.f1038j.isEmpty()) {
            return false;
        }
        C0065j jVar = new C0065j(this, new C0061h(this, this.b, this.f1278c, (View) this.f1283i));
        this.f1295u = jVar;
        ((View) this.f1282h).post(jVar);
        return true;
    }
}
