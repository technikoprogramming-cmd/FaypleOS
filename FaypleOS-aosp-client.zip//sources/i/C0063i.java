package i;

import h.C0039c;

/* renamed from: i.i  reason: case insensitive filesystem */
public final class C0063i extends C0039c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0069l f1255a;

    public C0063i(C0069l lVar) {
        this.f1255a = lVar;
    }
}
