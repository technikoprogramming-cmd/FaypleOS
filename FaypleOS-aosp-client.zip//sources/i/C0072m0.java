package i;

/* renamed from: i.m0  reason: case insensitive filesystem */
public interface C0072m0 {
}
