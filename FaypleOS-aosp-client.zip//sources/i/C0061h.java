package i;

import C.j;
import android.content.Context;
import android.view.View;
import h.n;
import h.v;
import h.x;
import nikodem.faypleos.server.R;

/* renamed from: i.h  reason: case insensitive filesystem */
public final class C0061h extends x {

    /* renamed from: l  reason: collision with root package name */
    public final /* synthetic */ int f1243l = 0;

    /* renamed from: m  reason: collision with root package name */
    public final /* synthetic */ C0069l f1244m;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0061h(C0069l lVar, Context context, n nVar, View view) {
        super(R.attr.actionOverflowMenuStyle, context, view, nVar, true);
        this.f1244m = lVar;
        this.f = 8388613;
        j jVar = lVar.f1297w;
        this.f1096h = jVar;
        v vVar = this.f1097i;
        if (vVar != null) {
            vVar.e(jVar);
        }
    }

    public final void c() {
        switch (this.f1243l) {
            case 0:
                C0069l lVar = this.f1244m;
                lVar.f1294t = null;
                lVar.getClass();
                super.c();
                return;
            default:
                C0069l lVar2 = this.f1244m;
                n nVar = lVar2.f1278c;
                if (nVar != null) {
                    nVar.c(true);
                }
                lVar2.f1293s = null;
                super.c();
                return;
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0061h(i.C0069l r8, android.content.Context r9, h.F r10, android.view.View r11) {
        /*
            r7 = this;
            r0 = 0
            r7.f1243l = r0
            r7.f1244m = r8
            r6 = 0
            r2 = 2130903072(0x7f030020, float:1.7412952E38)
            r1 = r7
            r3 = r9
            r5 = r10
            r4 = r11
            r1.<init>(r2, r3, r4, r5, r6)
            h.p r9 = r5.f973A
            int r9 = r9.f1079x
            r10 = 32
            r9 = r9 & r10
            if (r9 != r10) goto L_0x001a
            goto L_0x0024
        L_0x001a:
            i.k r9 = r8.f1283i
            if (r9 != 0) goto L_0x0022
            h.B r9 = r8.f1282h
            android.view.View r9 = (android.view.View) r9
        L_0x0022:
            r1.f1094e = r9
        L_0x0024:
            C.j r8 = r8.f1297w
            r1.f1096h = r8
            h.v r9 = r1.f1097i
            if (r9 == 0) goto L_0x002f
            r9.e(r8)
        L_0x002f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0061h.<init>(i.l, android.content.Context, h.F, android.view.View):void");
    }
}
