package i;

import android.view.View;

/* renamed from: i.g  reason: case insensitive filesystem */
public final class C0059g extends View {
    public final int getWindowSystemUiVisibility() {
        return 0;
    }
}
