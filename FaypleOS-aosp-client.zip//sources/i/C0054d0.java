package i;

import C.j;
import D.g;
import D.p;
import D.s;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import r.C0139f;
import w.b;
import w.c;

/* renamed from: i.d0  reason: case insensitive filesystem */
public class C0054d0 extends TextView {

    /* renamed from: a  reason: collision with root package name */
    public final C0079q f1223a;
    public final Z b;

    /* renamed from: c  reason: collision with root package name */
    public final E f1224c;

    /* renamed from: d  reason: collision with root package name */
    public C0094y f1225d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1226e;
    public j f;

    /* renamed from: g  reason: collision with root package name */
    public Future f1227g;

    public C0054d0(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    private C0094y getEmojiTextViewHelper() {
        if (this.f1225d == null) {
            this.f1225d = new C0094y(this);
        }
        return this.f1225d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            qVar.a();
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void g() {
        Future future = this.f1227g;
        if (future != null) {
            try {
                this.f1227g = null;
                if (future.get() != null) {
                    throw new ClassCastException();
                } else if (Build.VERSION.SDK_INT >= 29) {
                    throw null;
                } else {
                    g.y(this);
                    throw null;
                }
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (m1.f1299c) {
            return super.getAutoSizeMaxTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1206i.f1261e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (m1.f1299c) {
            return super.getAutoSizeMinTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1206i.f1260d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (m1.f1299c) {
            return super.getAutoSizeStepGranularity();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1206i.f1259c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (m1.f1299c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return z2.f1206i.f;
        }
        return new int[0];
    }

    public int getAutoSizeTextType() {
        if (!m1.f1299c) {
            Z z2 = this.b;
            if (z2 != null) {
                return z2.f1206i.f1258a;
            }
            return 0;
        } else if (super.getAutoSizeTextType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public C0048a0 getSuperCaller() {
        if (this.f == null) {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 34) {
                this.f = new C0052c0(this);
            } else if (i2 >= 28) {
                this.f = new C0050b0(this);
            } else if (i2 >= 26) {
                this.f = new j(19, (Object) this);
            }
        }
        return this.f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public CharSequence getText() {
        g();
        return super.getText();
    }

    public TextClassifier getTextClassifier() {
        E e2;
        if (Build.VERSION.SDK_INT >= 28 || (e2 = this.f1224c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) e2.f1111c;
        if (textClassifier == null) {
            return T.a((TextView) e2.b);
        }
        return textClassifier;
    }

    public b getTextMetricsParamsCompat() {
        return g.y(this);
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.b.getClass();
        Z.h(editorInfo, onCreateInputConnection, this);
        g.D(editorInfo, onCreateInputConnection, this);
        return onCreateInputConnection;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 && i2 < 33 && onCheckIsTextEditor()) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        Z z3 = this.b;
        if (z3 != null && !m1.f1299c) {
            z3.f1206i.a();
        }
    }

    public void onMeasure(int i2, int i3) {
        g();
        super.onMeasure(i2, i3);
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        Z z2 = this.b;
        if (z2 != null && !m1.f1299c) {
            C0064i0 i0Var = z2.f1206i;
            if (i0Var.f()) {
                i0Var.a();
            }
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (m1.f1299c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.i(i2, i3, i4, i5);
        }
    }

    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (m1.f1299c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.j(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (m1.f1299c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.k(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((g) getEmojiTextViewHelper().b.b).u(inputFilterArr));
    }

    public void setFirstBaselineToTopHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().d(i2);
        } else {
            g.P(this, i2);
        }
    }

    public void setLastBaselineToBottomHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().v(i2);
        } else {
            g.Q(this, i2);
        }
    }

    public void setLineHeight(int i2) {
        g.R(this, i2);
    }

    public void setPrecomputedText(c cVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        g.y(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q qVar = this.f1223a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.b;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.b;
        z2.m(mode);
        z2.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Z z2 = this.b;
        if (z2 != null) {
            z2.g(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        E e2;
        if (Build.VERSION.SDK_INT >= 28 || (e2 = this.f1224c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            e2.f1111c = textClassifier;
        }
    }

    public void setTextFuture(Future<c> future) {
        this.f1227g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(b bVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = bVar.b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i2 = 1;
        if (!(textDirectionHeuristic2 == textDirectionHeuristic3 || textDirectionHeuristic2 == (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR))) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i2 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        getPaint().set(bVar.f1540a);
        p.e(this, bVar.f1541c);
        p.h(this, bVar.f1542d);
    }

    public final void setTextSize(int i2, float f2) {
        boolean z2 = m1.f1299c;
        if (z2) {
            super.setTextSize(i2, f2);
            return;
        }
        Z z3 = this.b;
        if (z3 != null && !z2) {
            C0064i0 i0Var = z3.f1206i;
            if (!i0Var.f()) {
                i0Var.g(i2, f2);
            }
        }
    }

    public final void setTypeface(Typeface typeface, int i2) {
        Typeface typeface2;
        if (!this.f1226e) {
            if (typeface == null || i2 <= 0) {
                typeface2 = null;
            } else {
                Context context = getContext();
                g gVar = C0139f.f1504a;
                if (context != null) {
                    typeface2 = Typeface.create(typeface, i2);
                } else {
                    throw new IllegalArgumentException("Context cannot be null");
                }
            }
            this.f1226e = true;
            if (typeface2 != null) {
                typeface = typeface2;
            }
            try {
                super.setTypeface(typeface, i2);
            } finally {
                this.f1226e = false;
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0054d0(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        T0.a(context);
        this.f1226e = false;
        this.f = null;
        S0.a(this, getContext());
        C0079q qVar = new C0079q(this);
        this.f1223a = qVar;
        qVar.d(attributeSet, i2);
        Z z2 = new Z(this);
        this.b = z2;
        z2.f(attributeSet, i2);
        z2.b();
        E e2 = new E();
        e2.b = this;
        this.f1224c = e2;
        getEmojiTextViewHelper().a(attributeSet, i2);
    }

    public final void setLineHeight(int i2, float f2) {
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 34) {
            getSuperCaller().o(i2, f2);
        } else if (i3 >= 34) {
            s.a(this, i2, f2);
        } else {
            g.R(this, Math.round(TypedValue.applyDimension(i2, f2, getResources().getDisplayMetrics())));
        }
    }

    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable s2 = i2 != 0 ? g.s(context, i2) : null;
        Drawable s3 = i3 != 0 ? g.s(context, i3) : null;
        Drawable s4 = i4 != 0 ? g.s(context, i4) : null;
        if (i5 != 0) {
            drawable = g.s(context, i5);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(s2, s3, s4, drawable);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable s2 = i2 != 0 ? g.s(context, i2) : null;
        Drawable s3 = i3 != 0 ? g.s(context, i3) : null;
        Drawable s4 = i4 != 0 ? g.s(context, i4) : null;
        if (i5 != 0) {
            drawable = g.s(context, i5);
        }
        setCompoundDrawablesWithIntrinsicBounds(s2, s3, s4, drawable);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }
}
