package i;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import s.C0142a;

/* renamed from: i.r0  reason: case insensitive filesystem */
public final class C0081r0 extends Drawable implements Drawable.Callback {

    /* renamed from: a  reason: collision with root package name */
    public Drawable f1317a;
    public boolean b;

    public final void a(Canvas canvas) {
        this.f1317a.draw(canvas);
    }

    public final void b(float f, float f2) {
        C0142a.e(this.f1317a, f, f2);
    }

    public final void c(int i2, int i3, int i4, int i5) {
        C0142a.f(this.f1317a, i2, i3, i4, i5);
    }

    public final boolean d(boolean z2, boolean z3) {
        if (super.setVisible(z2, z3) || this.f1317a.setVisible(z2, z3)) {
            return true;
        }
        return false;
    }

    public final void draw(Canvas canvas) {
        if (this.b) {
            a(canvas);
        }
    }

    public final int getChangingConfigurations() {
        return this.f1317a.getChangingConfigurations();
    }

    public final Drawable getCurrent() {
        return this.f1317a.getCurrent();
    }

    public final int getIntrinsicHeight() {
        return this.f1317a.getIntrinsicHeight();
    }

    public final int getIntrinsicWidth() {
        return this.f1317a.getIntrinsicWidth();
    }

    public final int getMinimumHeight() {
        return this.f1317a.getMinimumHeight();
    }

    public final int getMinimumWidth() {
        return this.f1317a.getMinimumWidth();
    }

    public final int getOpacity() {
        return this.f1317a.getOpacity();
    }

    public final boolean getPadding(Rect rect) {
        return this.f1317a.getPadding(rect);
    }

    public final int[] getState() {
        return this.f1317a.getState();
    }

    public final Region getTransparentRegion() {
        return this.f1317a.getTransparentRegion();
    }

    public final void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public final boolean isAutoMirrored() {
        return this.f1317a.isAutoMirrored();
    }

    public final boolean isStateful() {
        return this.f1317a.isStateful();
    }

    public final void jumpToCurrentState() {
        this.f1317a.jumpToCurrentState();
    }

    public final void onBoundsChange(Rect rect) {
        this.f1317a.setBounds(rect);
    }

    public final boolean onLevelChange(int i2) {
        return this.f1317a.setLevel(i2);
    }

    public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        scheduleSelf(runnable, j2);
    }

    public final void setAlpha(int i2) {
        this.f1317a.setAlpha(i2);
    }

    public final void setAutoMirrored(boolean z2) {
        this.f1317a.setAutoMirrored(z2);
    }

    public final void setChangingConfigurations(int i2) {
        this.f1317a.setChangingConfigurations(i2);
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.f1317a.setColorFilter(colorFilter);
    }

    public final void setDither(boolean z2) {
        this.f1317a.setDither(z2);
    }

    public final void setFilterBitmap(boolean z2) {
        this.f1317a.setFilterBitmap(z2);
    }

    public final void setHotspot(float f, float f2) {
        if (this.b) {
            b(f, f2);
        }
    }

    public final void setHotspotBounds(int i2, int i3, int i4, int i5) {
        if (this.b) {
            c(i2, i3, i4, i5);
        }
    }

    public final boolean setState(int[] iArr) {
        if (this.b) {
            return this.f1317a.setState(iArr);
        }
        return false;
    }

    public final void setTint(int i2) {
        C0142a.g(this.f1317a, i2);
    }

    public final void setTintList(ColorStateList colorStateList) {
        C0142a.h(this.f1317a, colorStateList);
    }

    public final void setTintMode(PorterDuff.Mode mode) {
        C0142a.i(this.f1317a, mode);
    }

    public final boolean setVisible(boolean z2, boolean z3) {
        if (this.b) {
            return d(z2, z3);
        }
        return false;
    }

    public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
