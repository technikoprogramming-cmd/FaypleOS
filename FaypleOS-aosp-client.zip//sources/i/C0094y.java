package i;

import C.j;
import D.g;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import d.C0009a;

/* renamed from: i.y  reason: case insensitive filesystem */
public final class C0094y {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f1354a;
    public final j b;

    public C0094y(TextView textView) {
        this.f1354a = textView;
        this.b = new j(textView);
    }

    /* JADX INFO: finally extract failed */
    public final void a(AttributeSet attributeSet, int i2) {
        TypedArray obtainStyledAttributes = this.f1354a.getContext().obtainStyledAttributes(attributeSet, C0009a.f701i, i2, 0);
        try {
            boolean z2 = true;
            if (obtainStyledAttributes.hasValue(14)) {
                z2 = obtainStyledAttributes.getBoolean(14, true);
            }
            obtainStyledAttributes.recycle();
            c(z2);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void b(boolean z2) {
        ((g) this.b.b).N(z2);
    }

    public final void c(boolean z2) {
        ((g) this.b.b).O(z2);
    }
}
