package i;

import E.b;
import E.c;
import android.os.Parcel;
import android.os.Parcelable;

public final class c1 extends c {
    public static final Parcelable.Creator<c1> CREATOR = new b(1);

    /* renamed from: c  reason: collision with root package name */
    public int f1220c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1221d;

    public c1(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        boolean z2;
        this.f1220c = parcel.readInt();
        if (parcel.readInt() != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        this.f1221d = z2;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeInt(this.f1220c);
        parcel.writeInt(this.f1221d ? 1 : 0);
    }
}
