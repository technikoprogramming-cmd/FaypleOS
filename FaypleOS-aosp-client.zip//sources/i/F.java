package i;

import D.g;
import L.e;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;
import nikodem.faypleos.server.R;

public final class F extends RadioButton {

    /* renamed from: a  reason: collision with root package name */
    public final e f1113a;
    public final C0079q b;

    /* renamed from: c  reason: collision with root package name */
    public final Z f1114c;

    /* renamed from: d  reason: collision with root package name */
    public C0094y f1115d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public F(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.radioButtonStyle);
        T0.a(context);
        S0.a(this, getContext());
        e eVar = new e(this);
        this.f1113a = eVar;
        eVar.d(attributeSet, R.attr.radioButtonStyle);
        C0079q qVar = new C0079q(this);
        this.b = qVar;
        qVar.d(attributeSet, R.attr.radioButtonStyle);
        Z z2 = new Z(this);
        this.f1114c = z2;
        z2.f(attributeSet, R.attr.radioButtonStyle);
        getEmojiTextViewHelper().a(attributeSet, R.attr.radioButtonStyle);
    }

    private C0094y getEmojiTextViewHelper() {
        if (this.f1115d == null) {
            this.f1115d = new C0094y(this);
        }
        return this.f1115d;
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q qVar = this.b;
        if (qVar != null) {
            qVar.a();
        }
        Z z2 = this.f1114c;
        if (z2 != null) {
            z2.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q qVar = this.b;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q qVar = this.b;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        e eVar = this.f1113a;
        if (eVar != null) {
            return (ColorStateList) eVar.f116e;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        e eVar = this.f1113a;
        if (eVar != null) {
            return (PorterDuff.Mode) eVar.f;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1114c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1114c.e();
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q qVar = this.b;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q qVar = this.b;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        e eVar = this.f1113a;
        if (eVar == null) {
            return;
        }
        if (eVar.f114c) {
            eVar.f114c = false;
            return;
        }
        eVar.f114c = true;
        eVar.a();
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.f1114c;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.f1114c;
        if (z2 != null) {
            z2.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((g) getEmojiTextViewHelper().b.b).u(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q qVar = this.b;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q qVar = this.b;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        e eVar = this.f1113a;
        if (eVar != null) {
            eVar.f116e = colorStateList;
            eVar.f113a = true;
            eVar.a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        e eVar = this.f1113a;
        if (eVar != null) {
            eVar.f = mode;
            eVar.b = true;
            eVar.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.f1114c;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.f1114c;
        z2.m(mode);
        z2.b();
    }

    public void setButtonDrawable(int i2) {
        setButtonDrawable(g.s(getContext(), i2));
    }
}
