package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;

/* renamed from: i.v  reason: case insensitive filesystem */
public final class C0088v {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c  reason: collision with root package name */
    public static C0088v f1339c;

    /* renamed from: a  reason: collision with root package name */
    public N0 f1340a;

    public static synchronized C0088v a() {
        C0088v vVar;
        synchronized (C0088v.class) {
            try {
                if (f1339c == null) {
                    c();
                }
                vVar = f1339c;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        return vVar;
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [i.v, java.lang.Object] */
    public static synchronized void c() {
        synchronized (C0088v.class) {
            if (f1339c == null) {
                ? obj = new Object();
                f1339c = obj;
                obj.f1340a = N0.b();
                N0 n0 = f1339c.f1340a;
                C0086u uVar = new C0086u();
                synchronized (n0) {
                    n0.f1164e = uVar;
                }
            }
        }
    }

    public static void d(Drawable drawable, U0 u0, int[] iArr) {
        ColorStateList colorStateList;
        PorterDuff.Mode mode;
        PorterDuff.Mode mode2 = N0.f;
        int[] state = drawable.getState();
        if (drawable.mutate() == drawable) {
            if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
                drawable.setState(new int[0]);
                drawable.setState(state);
            }
            boolean z2 = u0.f1195d;
            if (z2 || u0.f1194c) {
                PorterDuffColorFilter porterDuffColorFilter = null;
                if (z2) {
                    colorStateList = u0.f1193a;
                } else {
                    colorStateList = null;
                }
                if (u0.f1194c) {
                    mode = u0.b;
                } else {
                    mode = N0.f;
                }
                if (!(colorStateList == null || mode == null)) {
                    porterDuffColorFilter = N0.e(colorStateList.getColorForState(iArr, 0), mode);
                }
                drawable.setColorFilter(porterDuffColorFilter);
                return;
            }
            drawable.clearColorFilter();
            return;
        }
        Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
    }

    public final synchronized Drawable b(Context context, int i2) {
        return this.f1340a.c(context, i2);
    }
}
