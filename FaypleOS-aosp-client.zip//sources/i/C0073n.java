package i;

/* renamed from: i.n  reason: case insensitive filesystem */
public final class C0073n extends C0093x0 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1300a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1301c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1302d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1303e;
    public boolean f;
}
