package i;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

/* renamed from: i.v0  reason: case insensitive filesystem */
public final class C0089v0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1341a;
    public final /* synthetic */ C0091w0 b;

    public /* synthetic */ C0089v0(C0091w0 w0Var, int i2) {
        this.f1341a = i2;
        this.b = w0Var;
    }

    public final void run() {
        switch (this.f1341a) {
            case 0:
                ViewParent parent = this.b.f1345d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    return;
                }
                return;
            default:
                C0091w0 w0Var = this.b;
                w0Var.a();
                View view = w0Var.f1345d;
                if (view.isEnabled() && !view.isLongClickable() && w0Var.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(obtain);
                    obtain.recycle();
                    w0Var.f1347g = true;
                    return;
                }
                return;
        }
    }
}
