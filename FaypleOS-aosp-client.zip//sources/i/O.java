package i;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import h.C0040d;
import nikodem.faypleos.server.R;

public final class O extends G0 implements Q {

    /* renamed from: B  reason: collision with root package name */
    public CharSequence f1165B;

    /* renamed from: C  reason: collision with root package name */
    public L f1166C;

    /* renamed from: D  reason: collision with root package name */
    public final Rect f1167D = new Rect();

    /* renamed from: E  reason: collision with root package name */
    public int f1168E;

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ S f1169F;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public O(S s2, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.spinnerStyle);
        this.f1169F = s2;
        this.f1131o = s2;
        this.f1140x = true;
        this.f1141y.setFocusable(true);
        this.f1132p = new M(this);
    }

    public final CharSequence b() {
        return this.f1165B;
    }

    public final void e(int i2, int i3) {
        ViewTreeObserver viewTreeObserver;
        C0046D d2 = this.f1141y;
        boolean isShowing = d2.isShowing();
        q();
        this.f1141y.setInputMethodMode(2);
        h();
        C0085t0 t0Var = this.f1120c;
        t0Var.setChoiceMode(1);
        t0Var.setTextDirection(i2);
        t0Var.setTextAlignment(i3);
        S s2 = this.f1169F;
        int selectedItemPosition = s2.getSelectedItemPosition();
        C0085t0 t0Var2 = this.f1120c;
        if (d2.isShowing() && t0Var2 != null) {
            t0Var2.setListSelectionHidden(false);
            t0Var2.setSelection(selectedItemPosition);
            if (t0Var2.getChoiceMode() != 0) {
                t0Var2.setItemChecked(selectedItemPosition, true);
            }
        }
        if (!isShowing && (viewTreeObserver = s2.getViewTreeObserver()) != null) {
            C0040d dVar = new C0040d(3, this);
            viewTreeObserver.addOnGlobalLayoutListener(dVar);
            this.f1141y.setOnDismissListener(new N(this, dVar));
        }
    }

    public final void g(CharSequence charSequence) {
        this.f1165B = charSequence;
    }

    public final void m(ListAdapter listAdapter) {
        super.m(listAdapter);
        this.f1166C = (L) listAdapter;
    }

    public final void n(int i2) {
        this.f1168E = i2;
    }

    public final void q() {
        int i2;
        int i3;
        C0046D d2 = this.f1141y;
        Drawable background = d2.getBackground();
        S s2 = this.f1169F;
        if (background != null) {
            background.getPadding(s2.f1183h);
            boolean z2 = m1.f1298a;
            int layoutDirection = s2.getLayoutDirection();
            Rect rect = s2.f1183h;
            if (layoutDirection == 1) {
                i2 = rect.right;
            } else {
                i2 = -rect.left;
            }
        } else {
            Rect rect2 = s2.f1183h;
            rect2.right = 0;
            rect2.left = 0;
            i2 = 0;
        }
        int paddingLeft = s2.getPaddingLeft();
        int paddingRight = s2.getPaddingRight();
        int width = s2.getWidth();
        int i4 = s2.f1182g;
        if (i4 == -2) {
            int a2 = s2.a(this.f1166C, d2.getBackground());
            int i5 = s2.getContext().getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = s2.f1183h;
            int i6 = (i5 - rect3.left) - rect3.right;
            if (a2 > i6) {
                a2 = i6;
            }
            p(Math.max(a2, (width - paddingLeft) - paddingRight));
        } else if (i4 == -1) {
            p((width - paddingLeft) - paddingRight);
        } else {
            p(i4);
        }
        boolean z3 = m1.f1298a;
        if (s2.getLayoutDirection() == 1) {
            i3 = (((width - paddingRight) - this.f1122e) - this.f1168E) + i2;
        } else {
            i3 = paddingLeft + this.f1168E + i2;
        }
        this.f = i3;
    }
}
