package i;

public final class P0 {

    /* renamed from: a  reason: collision with root package name */
    public int f1171a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f1172c;

    /* renamed from: d  reason: collision with root package name */
    public int f1173d;

    /* renamed from: e  reason: collision with root package name */
    public int f1174e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1175g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f1176h;

    public final void a(int i2, int i3) {
        this.f1172c = i2;
        this.f1173d = i3;
        this.f1176h = true;
        if (this.f1175g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f1171a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1171a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.b = i3;
        }
    }
}
