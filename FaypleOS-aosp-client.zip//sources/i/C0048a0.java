package i;

/* renamed from: i.a0  reason: case insensitive filesystem */
public interface C0048a0 {
    void d(int i2);

    void o(int i2, float f);

    void v(int i2);
}
