package i;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import h.l;
import h.n;

public final class X0 implements C0075o, l {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1199a;

    public /* synthetic */ X0(Toolbar toolbar) {
        this.f1199a = toolbar;
    }

    public void g(n nVar) {
        Toolbar toolbar = this.f1199a;
        C0069l lVar = toolbar.f438a.f402t;
        if (lVar == null || !lVar.h()) {
            toolbar.f427G.h();
        }
    }

    public boolean h(n nVar, MenuItem menuItem) {
        this.f1199a.getClass();
        return false;
    }
}
