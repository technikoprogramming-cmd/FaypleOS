package i;

import android.view.View;

public abstract class f1 {
    public static void a(View view, CharSequence charSequence) {
        view.setTooltipText(charSequence);
    }
}
