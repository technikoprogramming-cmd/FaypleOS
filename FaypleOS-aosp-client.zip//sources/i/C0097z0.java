package i;

import android.view.View;
import android.widget.AdapterView;

/* renamed from: i.z0  reason: case insensitive filesystem */
public final class C0097z0 implements AdapterView.OnItemSelectedListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ G0 f1370a;

    public C0097z0(G0 g0) {
        this.f1370a = g0;
    }

    public final void onItemSelected(AdapterView adapterView, View view, int i2, long j2) {
        C0085t0 t0Var;
        if (i2 != -1 && (t0Var = this.f1370a.f1120c) != null) {
            t0Var.setListSelectionHidden(false);
        }
    }

    public final void onNothingSelected(AdapterView adapterView) {
    }
}
