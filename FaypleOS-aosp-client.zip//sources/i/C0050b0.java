package i;

import C.j;

/* renamed from: i.b0  reason: case insensitive filesystem */
public class C0050b0 extends j {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0054d0 f1217c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0050b0(C0054d0 d0Var) {
        super(19, (Object) d0Var);
        this.f1217c = d0Var;
    }

    public final void d(int i2) {
        C0050b0.super.setFirstBaselineToTopHeight(i2);
    }

    public final void v(int i2) {
        C0050b0.super.setLastBaselineToBottomHeight(i2);
    }
}
