package i;

import C.j;
import D.g;
import D.u;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import nikodem.faypleos.server.R;
import y.C0161e;
import y.C0163g;
import y.K;
import y.r;

/* renamed from: i.x  reason: case insensitive filesystem */
public final class C0092x extends EditText implements r {

    /* renamed from: a  reason: collision with root package name */
    public final C0079q f1350a;
    public final Z b;

    /* renamed from: c  reason: collision with root package name */
    public final E f1351c;

    /* renamed from: d  reason: collision with root package name */
    public final u f1352d = new Object();

    /* renamed from: e  reason: collision with root package name */
    public final E f1353e;
    public C0090w f;

    /* JADX WARNING: type inference failed for: r5v5, types: [java.lang.Object, D.u] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0092x(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.editTextStyle);
        T0.a(context);
        S0.a(this, getContext());
        C0079q qVar = new C0079q(this);
        this.f1350a = qVar;
        qVar.d(attributeSet, R.attr.editTextStyle);
        Z z2 = new Z(this);
        this.b = z2;
        z2.f(attributeSet, R.attr.editTextStyle);
        z2.b();
        E e2 = new E();
        e2.b = this;
        this.f1351c = e2;
        E e3 = new E((EditText) this);
        this.f1353e = e3;
        e3.b(attributeSet, R.attr.editTextStyle);
        KeyListener keyListener = getKeyListener();
        if (!(keyListener instanceof NumberKeyListener)) {
            boolean isFocusable = isFocusable();
            boolean isClickable = isClickable();
            boolean isLongClickable = isLongClickable();
            int inputType = getInputType();
            KeyListener a2 = e3.a(keyListener);
            if (a2 != keyListener) {
                super.setKeyListener(a2);
                setRawInputType(inputType);
                setFocusable(isFocusable);
                setClickable(isClickable);
                setLongClickable(isLongClickable);
            }
        }
    }

    private C0090w getSuperCaller() {
        if (this.f == null) {
            this.f = new C0090w(this);
        }
        return this.f;
    }

    public final C0163g a(C0163g gVar) {
        return this.f1352d.a(this, gVar);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            qVar.a();
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return g.T(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    public TextClassifier getTextClassifier() {
        E e2;
        if (Build.VERSION.SDK_INT >= 28 || (e2 = this.f1351c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) e2.f1111c;
        if (textClassifier == null) {
            return T.a((TextView) e2.b);
        }
        return textClassifier;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0054, code lost:
        if (r1 != null) goto L_0x0056;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0069, code lost:
        if (r1 != null) goto L_0x0056;
     */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0070  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo r8) {
        /*
            r7 = this;
            android.view.inputmethod.InputConnection r0 = super.onCreateInputConnection(r8)
            i.Z r1 = r7.b
            r1.getClass()
            i.Z.h(r8, r0, r7)
            D.g.D(r8, r0, r7)
            if (r0 == 0) goto L_0x0076
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 30
            if (r1 > r2) goto L_0x0076
            java.lang.String[] r2 = y.K.d(r7)
            if (r2 == 0) goto L_0x0076
            java.lang.String r3 = "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
            java.lang.String r4 = "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
            r5 = 25
            if (r1 < r5) goto L_0x0029
            r8.contentMimeTypes = r2
            goto L_0x003e
        L_0x0029:
            android.os.Bundle r6 = r8.extras
            if (r6 != 0) goto L_0x0034
            android.os.Bundle r6 = new android.os.Bundle
            r6.<init>()
            r8.extras = r6
        L_0x0034:
            android.os.Bundle r6 = r8.extras
            r6.putStringArray(r4, r2)
            android.os.Bundle r6 = r8.extras
            r6.putStringArray(r3, r2)
        L_0x003e:
            C.d r2 = new C.d
            r2.<init>(r7)
            if (r1 < r5) goto L_0x004c
            C.e r1 = new C.e
            r1.<init>(r0, r2)
        L_0x004a:
            r0 = r1
            goto L_0x0076
        L_0x004c:
            java.lang.String[] r6 = C.c.f0a
            if (r1 < r5) goto L_0x0058
            java.lang.String[] r1 = r8.contentMimeTypes
            if (r1 == 0) goto L_0x006c
        L_0x0056:
            r6 = r1
            goto L_0x006c
        L_0x0058:
            android.os.Bundle r1 = r8.extras
            if (r1 != 0) goto L_0x005d
            goto L_0x006c
        L_0x005d:
            java.lang.String[] r1 = r1.getStringArray(r4)
            if (r1 != 0) goto L_0x0069
            android.os.Bundle r1 = r8.extras
            java.lang.String[] r1 = r1.getStringArray(r3)
        L_0x0069:
            if (r1 == 0) goto L_0x006c
            goto L_0x0056
        L_0x006c:
            int r1 = r6.length
            if (r1 != 0) goto L_0x0070
            goto L_0x0076
        L_0x0070:
            C.f r1 = new C.f
            r1.<init>(r0, r2)
            goto L_0x004a
        L_0x0076:
            i.E r1 = r7.f1353e
            G.c r8 = r1.c(r0, r8)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0092x.onCreateInputConnection(android.view.inputmethod.EditorInfo):android.view.inputmethod.InputConnection");
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 && i2 < 33) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    public final boolean onDragEvent(DragEvent dragEvent) {
        Activity activity;
        boolean z2 = false;
        if (Build.VERSION.SDK_INT < 31 && dragEvent.getLocalState() == null && K.d(this) != null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    activity = null;
                    break;
                } else if (context instanceof Activity) {
                    activity = (Activity) context;
                    break;
                } else {
                    context = ((ContextWrapper) context).getBaseContext();
                }
            }
            if (activity == null) {
                Log.i("ReceiveContent", "Can't handle drop: no activity: view=" + this);
            } else if (dragEvent.getAction() != 1 && dragEvent.getAction() == 3) {
                z2 = G.a(dragEvent, this, activity);
            }
        }
        if (z2) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    public final boolean onTextContextMenuItem(int i2) {
        ClipData clipData;
        j jVar;
        int i3;
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 31 || K.d(this) == null || (i2 != 16908322 && i2 != 16908337)) {
            return super.onTextContextMenuItem(i2);
        }
        ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService("clipboard");
        if (clipboardManager == null) {
            clipData = null;
        } else {
            clipData = clipboardManager.getPrimaryClip();
        }
        if (clipData != null && clipData.getItemCount() > 0) {
            if (i4 >= 31) {
                jVar = new j(clipData, 1);
            } else {
                C0161e eVar = new C0161e();
                eVar.b = clipData;
                eVar.f1581c = 1;
                jVar = eVar;
            }
            if (i2 == 16908322) {
                i3 = 0;
            } else {
                i3 = 1;
            }
            jVar.w(i3);
            K.f(this, jVar.k());
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(g.U(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f1353e.d(z2);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1353e.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q qVar = this.f1350a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.b;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.b;
        z2.m(mode);
        z2.b();
    }

    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Z z2 = this.b;
        if (z2 != null) {
            z2.g(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        E e2;
        if (Build.VERSION.SDK_INT >= 28 || (e2 = this.f1351c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            e2.f1111c = textClassifier;
        }
    }

    public Editable getText() {
        if (Build.VERSION.SDK_INT >= 28) {
            return super.getText();
        }
        return getEditableText();
    }
}
