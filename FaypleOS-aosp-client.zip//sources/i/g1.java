package i;

public final /* synthetic */ class g1 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1242a;
    public final /* synthetic */ h1 b;

    public /* synthetic */ g1(h1 h1Var, int i2) {
        this.f1242a = i2;
        this.b = h1Var;
    }

    public final void run() {
        switch (this.f1242a) {
            case 0:
                this.b.c(false);
                return;
            default:
                this.b.a();
                return;
        }
    }
}
