package i;

import C.h;
import D.g;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import d.C0009a;
import y.K;

/* renamed from: i.A  reason: case insensitive filesystem */
public final class C0043A {

    /* renamed from: a  reason: collision with root package name */
    public final ImageView f1100a;
    public U0 b;

    /* renamed from: c  reason: collision with root package name */
    public int f1101c = 0;

    public C0043A(ImageView imageView) {
        this.f1100a = imageView;
    }

    public final void a() {
        U0 u0;
        ImageView imageView = this.f1100a;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            C0074n0.a(drawable);
        }
        if (drawable != null && (u0 = this.b) != null) {
            C0088v.d(drawable, u0, imageView.getDrawableState());
        }
    }

    public final void b(AttributeSet attributeSet, int i2) {
        ImageView imageView = this.f1100a;
        Context context = imageView.getContext();
        int[] iArr = C0009a.f;
        h p2 = h.p(context, attributeSet, iArr, i2);
        K.g(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) p2.b, i2);
        try {
            Drawable drawable = imageView.getDrawable();
            TypedArray typedArray = (TypedArray) p2.b;
            if (drawable == null) {
                int resourceId = typedArray.getResourceId(1, -1);
                if (!(resourceId == -1 || (drawable = g.s(imageView.getContext(), resourceId)) == null)) {
                    imageView.setImageDrawable(drawable);
                }
            }
            if (drawable != null) {
                C0074n0.a(drawable);
            }
            if (typedArray.hasValue(2)) {
                D.h.c(imageView, p2.j(2));
            }
            if (typedArray.hasValue(3)) {
                D.h.d(imageView, C0074n0.b(typedArray.getInt(3, -1), (PorterDuff.Mode) null));
            }
            p2.r();
        } catch (Throwable th) {
            Throwable th2 = th;
            p2.r();
            throw th2;
        }
    }
}
