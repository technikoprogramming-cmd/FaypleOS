package i;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import y.S;

/* renamed from: i.c  reason: case insensitive filesystem */
public final class C0051c extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1218a = 0;
    public final /* synthetic */ Object b;

    public C0051c(ActionBarOverlayLayout actionBarOverlayLayout) {
        this.b = actionBarOverlayLayout;
    }

    public final void onAnimationCancel(Animator animator) {
        switch (this.f1218a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.b;
                actionBarOverlayLayout.f394w = null;
                actionBarOverlayLayout.f381j = false;
                return;
            default:
                ((S) this.b).b();
                return;
        }
    }

    public final void onAnimationEnd(Animator animator) {
        switch (this.f1218a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.b;
                actionBarOverlayLayout.f394w = null;
                actionBarOverlayLayout.f381j = false;
                return;
            default:
                ((S) this.b).a();
                return;
        }
    }

    public void onAnimationStart(Animator animator) {
        switch (this.f1218a) {
            case 1:
                ((S) this.b).c();
                return;
            default:
                super.onAnimationStart(animator);
                return;
        }
    }

    public C0051c(S s2, View view) {
        this.b = s2;
    }
}
