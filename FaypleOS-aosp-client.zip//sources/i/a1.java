package i;

import android.view.ViewGroup;

public final class a1 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a  reason: collision with root package name */
    public int f1215a = 0;
    public int b;

    public a1(a1 a1Var) {
        super(a1Var);
        this.f1215a = a1Var.f1215a;
    }

    public a1(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }
}
