package i;

import androidx.appcompat.widget.ActionBarOverlayLayout;

/* renamed from: i.d  reason: case insensitive filesystem */
public final class C0053d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1222a;
    public final /* synthetic */ ActionBarOverlayLayout b;

    public /* synthetic */ C0053d(ActionBarOverlayLayout actionBarOverlayLayout, int i2) {
        this.f1222a = i2;
        this.b = actionBarOverlayLayout;
    }

    public final void run() {
        switch (this.f1222a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.b;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f394w = actionBarOverlayLayout.f376d.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f395x);
                return;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.b;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f394w = actionBarOverlayLayout2.f376d.animate().translationY((float) (-actionBarOverlayLayout2.f376d.getHeight())).setListener(actionBarOverlayLayout2.f395x);
                return;
        }
    }
}
