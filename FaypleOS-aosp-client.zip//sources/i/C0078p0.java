package i;

import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import java.lang.reflect.Method;

/* renamed from: i.p0  reason: case insensitive filesystem */
public abstract class C0078p0 {

    /* renamed from: a  reason: collision with root package name */
    public static final Method f1308a;
    public static final Method b;

    /* renamed from: c  reason: collision with root package name */
    public static final Method f1309c;

    /* renamed from: d  reason: collision with root package name */
    public static final boolean f1310d = true;

    static {
        Class<AdapterView> cls = AdapterView.class;
        Class<AbsListView> cls2 = AbsListView.class;
        try {
            Class cls3 = Integer.TYPE;
            Class cls4 = Boolean.TYPE;
            Class cls5 = Float.TYPE;
            Method declaredMethod = cls2.getDeclaredMethod("positionSelector", new Class[]{cls3, View.class, cls4, cls5, cls5});
            f1308a = declaredMethod;
            declaredMethod.setAccessible(true);
            Method declaredMethod2 = cls.getDeclaredMethod("setSelectedPositionInt", new Class[]{cls3});
            b = declaredMethod2;
            declaredMethod2.setAccessible(true);
            Method declaredMethod3 = cls.getDeclaredMethod("setNextSelectedPositionInt", new Class[]{cls3});
            f1309c = declaredMethod3;
            declaredMethod3.setAccessible(true);
        } catch (NoSuchMethodException e2) {
            e2.printStackTrace();
        }
    }
}
