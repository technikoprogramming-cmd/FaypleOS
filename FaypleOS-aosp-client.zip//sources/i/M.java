package i;

import android.view.View;
import android.widget.AdapterView;

public final class M implements AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ O f1157a;

    public M(O o2) {
        this.f1157a = o2;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        O o2 = this.f1157a;
        o2.f1169F.setSelection(i2);
        S s2 = o2.f1169F;
        if (s2.getOnItemClickListener() != null) {
            s2.performItemClick(view, i2, o2.f1166C.getItemId(i2));
        }
        o2.dismiss();
    }
}
