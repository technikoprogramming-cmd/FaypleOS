package i;

import android.widget.AbsListView;

/* renamed from: i.q0  reason: case insensitive filesystem */
public abstract class C0080q0 {
    public static boolean a(AbsListView absListView) {
        return absListView.isSelectedChildViewEnabled();
    }

    public static void b(AbsListView absListView, boolean z2) {
        absListView.setSelectedChildViewEnabled(z2);
    }
}
