package i;

public final class C0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1107a;
    public final /* synthetic */ G0 b;

    public /* synthetic */ C0(G0 g0, int i2) {
        this.f1107a = i2;
        this.b = g0;
    }

    public final void run() {
        switch (this.f1107a) {
            case 0:
                C0085t0 t0Var = this.b.f1120c;
                if (t0Var != null) {
                    t0Var.setListSelectionHidden(true);
                    t0Var.requestLayout();
                    return;
                }
                return;
            default:
                G0 g0 = this.b;
                C0085t0 t0Var2 = g0.f1120c;
                if (t0Var2 != null && t0Var2.isAttachedToWindow() && g0.f1120c.getCount() > g0.f1120c.getChildCount() && g0.f1120c.getChildCount() <= g0.f1129m) {
                    g0.f1141y.setInputMethodMode(2);
                    g0.h();
                    return;
                }
                return;
        }
    }
}
