package i;

/* renamed from: i.e  reason: case insensitive filesystem */
public interface C0055e {
}
