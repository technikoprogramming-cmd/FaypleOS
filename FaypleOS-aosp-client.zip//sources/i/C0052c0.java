package i;

/* renamed from: i.c0  reason: case insensitive filesystem */
public final class C0052c0 extends C0050b0 {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0054d0 f1219d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0052c0(C0054d0 d0Var) {
        super(d0Var);
        this.f1219d = d0Var;
    }

    public final void o(int i2, float f) {
        C0052c0.super.setLineHeight(i2, f);
    }
}
