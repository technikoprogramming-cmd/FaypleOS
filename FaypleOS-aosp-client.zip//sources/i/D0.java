package i;

import android.database.DataSetObserver;

public final class D0 extends DataSetObserver {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ G0 f1108a;

    public D0(G0 g0) {
        this.f1108a = g0;
    }

    public final void onChanged() {
        G0 g0 = this.f1108a;
        if (g0.f1141y.isShowing()) {
            g0.h();
        }
    }

    public final void onInvalidated() {
        this.f1108a.dismiss();
    }
}
