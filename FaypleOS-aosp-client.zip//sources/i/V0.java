package i;

public abstract class V0 extends O0 {
}
