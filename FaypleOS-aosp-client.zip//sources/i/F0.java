package i;

import android.view.MotionEvent;
import android.view.View;

public final class F0 implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ G0 f1116a;

    public F0(G0 g0) {
        this.f1116a = g0;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        C0046D d2;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        G0 g0 = this.f1116a;
        if (action == 0 && (d2 = g0.f1141y) != null && d2.isShowing() && x2 >= 0 && x2 < g0.f1141y.getWidth() && y2 >= 0 && y2 < g0.f1141y.getHeight()) {
            g0.f1137u.postDelayed(g0.f1133q, 250);
            return false;
        } else if (action != 1) {
            return false;
        } else {
            g0.f1137u.removeCallbacks(g0.f1133q);
            return false;
        }
    }
}
