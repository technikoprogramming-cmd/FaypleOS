package i;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import h.C0040d;

public final class N implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0040d f1158a;
    public final /* synthetic */ O b;

    public N(O o2, C0040d dVar) {
        this.b = o2;
        this.f1158a = dVar;
    }

    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.f1169F.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1158a);
        }
    }
}
