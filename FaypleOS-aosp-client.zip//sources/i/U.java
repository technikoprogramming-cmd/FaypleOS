package i;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import androidx.activity.c;
import java.lang.ref.WeakReference;

public final class U {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1190a;
    public final /* synthetic */ int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ WeakReference f1191c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ Z f1192d;

    public U(Z z2, int i2, int i3, WeakReference weakReference) {
        this.f1192d = z2;
        this.f1190a = i2;
        this.b = i3;
        this.f1191c = weakReference;
    }

    public final void a() {
        new Handler(Looper.getMainLooper()).post(new c(6, this));
    }

    public final void b(Typeface typeface) {
        int i2;
        boolean z2;
        if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f1190a) != -1) {
            if ((this.b & 2) != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            typeface = Y.a(typeface, i2, z2);
        }
        Z z3 = this.f1192d;
        if (z3.f1210m) {
            z3.f1209l = typeface;
            TextView textView = (TextView) this.f1191c.get();
            if (textView == null) {
                return;
            }
            if (textView.isAttachedToWindow()) {
                textView.post(new V(textView, typeface, z3.f1207j));
            } else {
                textView.setTypeface(typeface, z3.f1207j);
            }
        }
    }
}
