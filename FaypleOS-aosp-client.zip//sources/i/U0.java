package i;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public final class U0 {

    /* renamed from: a  reason: collision with root package name */
    public ColorStateList f1193a;
    public PorterDuff.Mode b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1194c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1195d;
}
