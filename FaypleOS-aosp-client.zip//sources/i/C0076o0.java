package i;

import android.view.View;

/* renamed from: i.o0  reason: case insensitive filesystem */
public abstract class C0076o0 {
    public static void a(View view, float f, float f2) {
        view.drawableHotspotChanged(f, f2);
    }
}
