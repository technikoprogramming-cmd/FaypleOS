package i;

/* renamed from: i.w  reason: case insensitive filesystem */
public final class C0090w {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0092x f1342a;

    public C0090w(C0092x xVar) {
        this.f1342a = xVar;
    }
}
