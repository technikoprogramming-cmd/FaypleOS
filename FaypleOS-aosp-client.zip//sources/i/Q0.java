package i;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

public abstract class Q0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
