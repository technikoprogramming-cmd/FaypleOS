package i;

import android.graphics.drawable.Drawable;
import android.widget.ListAdapter;

public interface Q {
    boolean a();

    CharSequence b();

    void c(int i2);

    int d();

    void dismiss();

    void e(int i2, int i3);

    void g(CharSequence charSequence);

    int i();

    void j(Drawable drawable);

    void k(int i2);

    Drawable l();

    void m(ListAdapter listAdapter);

    void n(int i2);
}
