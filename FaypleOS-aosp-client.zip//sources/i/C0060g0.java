package i;

import android.text.StaticLayout;
import android.widget.TextView;

/* renamed from: i.g0  reason: case insensitive filesystem */
public final class C0060g0 extends C0058f0 {
    public void a(StaticLayout.Builder builder, TextView textView) {
        builder.setTextDirection(textView.getTextDirectionHeuristic());
    }

    public boolean b(TextView textView) {
        return textView.isHorizontallyScrollable();
    }
}
