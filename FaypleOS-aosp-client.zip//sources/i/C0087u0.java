package i;

/* renamed from: i.u0  reason: case insensitive filesystem */
public interface C0087u0 {
}
