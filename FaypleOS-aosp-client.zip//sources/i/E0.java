package i;

import android.os.Handler;
import android.widget.AbsListView;

public final class E0 implements AbsListView.OnScrollListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ G0 f1112a;

    public E0(G0 g0) {
        this.f1112a = g0;
    }

    public final void onScrollStateChanged(AbsListView absListView, int i2) {
        if (i2 == 1) {
            G0 g0 = this.f1112a;
            if (g0.f1141y.getInputMethodMode() != 2 && g0.f1141y.getContentView() != null) {
                Handler handler = g0.f1137u;
                C0 c02 = g0.f1133q;
                handler.removeCallbacks(c02);
                c02.run();
            }
        }
    }

    public final void onScroll(AbsListView absListView, int i2, int i3, int i4) {
    }
}
