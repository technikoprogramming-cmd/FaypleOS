package i;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import androidx.appcompat.widget.ActionBarContainer;

/* renamed from: i.b  reason: case insensitive filesystem */
public final class C0049b extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public final ActionBarContainer f1216a;

    public C0049b(ActionBarContainer actionBarContainer) {
        this.f1216a = actionBarContainer;
    }

    public final void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.f1216a;
        if (actionBarContainer.f348g) {
            Drawable drawable = actionBarContainer.f;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
            return;
        }
        Drawable drawable2 = actionBarContainer.f346d;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Drawable drawable3 = actionBarContainer.f347e;
        if (drawable3 != null && actionBarContainer.f349h) {
            drawable3.draw(canvas);
        }
    }

    public final int getOpacity() {
        return 0;
    }

    public final void getOutline(Outline outline) {
        ActionBarContainer actionBarContainer = this.f1216a;
        if (!actionBarContainer.f348g) {
            Drawable drawable = actionBarContainer.f346d;
            if (drawable != null) {
                drawable.getOutline(outline);
            }
        } else if (actionBarContainer.f != null) {
            actionBarContainer.f346d.getOutline(outline);
        }
    }

    public final void setAlpha(int i2) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
