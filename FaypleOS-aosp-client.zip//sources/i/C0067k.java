package i;

import D.g;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import h.C0038b;
import nikodem.faypleos.server.R;
import s.C0142a;

/* renamed from: i.k  reason: case insensitive filesystem */
public final class C0067k extends C0044B implements C0071m {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0069l f1276d;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0067k(C0069l lVar, Context context) {
        super(context, (AttributeSet) null, R.attr.actionOverflowButtonStyle);
        this.f1276d = lVar;
        setClickable(true);
        setFocusable(true);
        setVisibility(0);
        setEnabled(true);
        g.S(this, getContentDescription());
        setOnTouchListener(new C0038b(this, this));
    }

    public final boolean a() {
        return false;
    }

    public final boolean b() {
        return false;
    }

    public final boolean performClick() {
        if (super.performClick()) {
            return true;
        }
        playSoundEffect(0);
        this.f1276d.l();
        return true;
    }

    public final boolean setFrame(int i2, int i3, int i4, int i5) {
        boolean frame = super.setFrame(i2, i3, i4, i5);
        Drawable drawable = getDrawable();
        Drawable background = getBackground();
        if (!(drawable == null || background == null)) {
            int width = getWidth();
            int height = getHeight();
            int max = Math.max(width, height) / 2;
            int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
            int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
            C0142a.f(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
        }
        return frame;
    }
}
