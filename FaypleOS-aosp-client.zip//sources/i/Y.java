package i;

import android.graphics.Typeface;

public abstract class Y {
    public static Typeface a(Typeface typeface, int i2, boolean z2) {
        return Typeface.create(typeface, i2, z2);
    }
}
