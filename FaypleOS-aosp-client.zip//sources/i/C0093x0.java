package i;

import android.widget.LinearLayout;

/* renamed from: i.x0  reason: case insensitive filesystem */
public class C0093x0 extends LinearLayout.LayoutParams {
}
