package i;

import android.view.View;
import h.l;
import h.n;

/* renamed from: i.j  reason: case insensitive filesystem */
public final class C0065j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final C0061h f1272a;
    public final /* synthetic */ C0069l b;

    public C0065j(C0069l lVar, C0061h hVar) {
        this.b = lVar;
        this.f1272a = hVar;
    }

    public final void run() {
        l lVar;
        C0069l lVar2 = this.b;
        n nVar = lVar2.f1278c;
        if (!(nVar == null || (lVar = nVar.f1034e) == null)) {
            lVar.g(nVar);
        }
        View view = (View) lVar2.f1282h;
        if (!(view == null || view.getWindowToken() == null)) {
            C0061h hVar = this.f1272a;
            if (!hVar.b()) {
                if (hVar.f1094e != null) {
                    hVar.d(0, 0, false, false);
                }
            }
            lVar2.f1293s = hVar;
        }
        lVar2.f1295u = null;
    }
}
