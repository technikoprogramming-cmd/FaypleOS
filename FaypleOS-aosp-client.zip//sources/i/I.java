package i;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.AbsSeekBar;
import d.C0009a;
import nikodem.faypleos.server.R;
import s.C0142a;
import s.C0143b;
import y.K;

public final class I extends E {

    /* renamed from: e  reason: collision with root package name */
    public final H f1143e;
    public Drawable f;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f1144g = null;

    /* renamed from: h  reason: collision with root package name */
    public PorterDuff.Mode f1145h = null;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1146i = false;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1147j = false;

    public I(H h2) {
        super((AbsSeekBar) h2);
        this.f1143e = h2;
    }

    public final void b(AttributeSet attributeSet, int i2) {
        super.b(attributeSet, R.attr.seekBarStyle);
        H h2 = this.f1143e;
        Context context = h2.getContext();
        int[] iArr = C0009a.f699g;
        h p2 = h.p(context, attributeSet, iArr, R.attr.seekBarStyle);
        K.g(h2, h2.getContext(), iArr, attributeSet, (TypedArray) p2.b, R.attr.seekBarStyle);
        Drawable l2 = p2.l(0);
        if (l2 != null) {
            h2.setThumb(l2);
        }
        Drawable k2 = p2.k(1);
        Drawable drawable = this.f;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
        this.f = k2;
        if (k2 != null) {
            k2.setCallback(h2);
            C0143b.b(k2, h2.getLayoutDirection());
            if (k2.isStateful()) {
                k2.setState(h2.getDrawableState());
            }
            f();
        }
        h2.invalidate();
        TypedArray typedArray = (TypedArray) p2.b;
        if (typedArray.hasValue(3)) {
            this.f1145h = C0074n0.b(typedArray.getInt(3, -1), this.f1145h);
            this.f1147j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f1144g = p2.j(2);
            this.f1146i = true;
        }
        p2.r();
        f();
    }

    public final void f() {
        Drawable drawable = this.f;
        if (drawable == null) {
            return;
        }
        if (this.f1146i || this.f1147j) {
            Drawable mutate = drawable.mutate();
            this.f = mutate;
            if (this.f1146i) {
                C0142a.h(mutate, this.f1144g);
            }
            if (this.f1147j) {
                C0142a.i(this.f, this.f1145h);
            }
            if (this.f.isStateful()) {
                this.f.setState(this.f1143e.getDrawableState());
            }
        }
    }

    public final void g(Canvas canvas) {
        int i2;
        if (this.f != null) {
            H h2 = this.f1143e;
            int max = h2.getMax();
            int i3 = 1;
            if (max > 1) {
                int intrinsicWidth = this.f.getIntrinsicWidth();
                int intrinsicHeight = this.f.getIntrinsicHeight();
                if (intrinsicWidth >= 0) {
                    i2 = intrinsicWidth / 2;
                } else {
                    i2 = 1;
                }
                if (intrinsicHeight >= 0) {
                    i3 = intrinsicHeight / 2;
                }
                this.f.setBounds(-i2, -i3, i2, i3);
                float width = ((float) ((h2.getWidth() - h2.getPaddingLeft()) - h2.getPaddingRight())) / ((float) max);
                int save = canvas.save();
                canvas.translate((float) h2.getPaddingLeft(), (float) (h2.getHeight() / 2));
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }
}
