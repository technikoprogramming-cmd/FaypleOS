package i;

import android.widget.AbsListView;
import java.lang.reflect.Field;

/* renamed from: i.s0  reason: case insensitive filesystem */
public abstract class C0083s0 {

    /* renamed from: a  reason: collision with root package name */
    public static final Field f1321a;

    static {
        Field field = null;
        try {
            field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
            field.setAccessible(true);
        } catch (NoSuchFieldException e2) {
            e2.printStackTrace();
        }
        f1321a = field;
    }
}
