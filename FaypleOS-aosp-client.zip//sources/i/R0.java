package i;

import g.C0026b;

public abstract class R0 extends C0095y0 implements C0026b {
}
