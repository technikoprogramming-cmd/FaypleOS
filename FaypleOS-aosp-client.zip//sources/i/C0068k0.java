package i;

/* renamed from: i.k0  reason: case insensitive filesystem */
public interface C0068k0 {
}
