package i;

import androidx.appcompat.widget.Toolbar;
import h.p;

public final /* synthetic */ class W0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f1198a;
    public final /* synthetic */ Toolbar b;

    public /* synthetic */ W0(Toolbar toolbar, int i2) {
        this.f1198a = i2;
        this.b = toolbar;
    }

    public final void run() {
        p pVar;
        switch (this.f1198a) {
            case 0:
                Z0 z0 = this.b.f432L;
                if (z0 == null) {
                    pVar = null;
                } else {
                    pVar = z0.b;
                }
                if (pVar != null) {
                    pVar.collapseActionView();
                    return;
                }
                return;
            default:
                this.b.m();
                return;
        }
    }
}
