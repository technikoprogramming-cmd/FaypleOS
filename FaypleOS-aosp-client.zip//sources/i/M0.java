package i;

import l.C0110f;

public final class M0 extends C0110f {
}
