package i;

public interface k1 {
}
