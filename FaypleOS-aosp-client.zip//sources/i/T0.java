package i;

import android.content.Context;
import android.content.ContextWrapper;

public abstract class T0 extends ContextWrapper {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f1189a = null;

    public static void a(Context context) {
        if (!(context.getResources() instanceof V0)) {
            context.getResources();
            int i2 = j1.f1275a;
        }
    }
}
