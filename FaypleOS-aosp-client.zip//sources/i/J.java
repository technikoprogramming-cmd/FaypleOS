package i;

import h.D;

public final class J extends C0091w0 {

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ O f1148j;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ S f1149k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public J(S s2, S s3, O o2) {
        super(s3);
        this.f1149k = s2;
        this.f1148j = o2;
    }

    public final D b() {
        return this.f1148j;
    }

    public final boolean c() {
        S s2 = this.f1149k;
        if (s2.getInternalPopup().a()) {
            return true;
        }
        s2.f.e(s2.getTextDirection(), s2.getTextAlignment());
        return true;
    }
}
