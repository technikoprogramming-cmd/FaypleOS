package i;

import h.n;
import h.p;

public interface H0 {
    void r(n nVar, p pVar);

    void t(n nVar, p pVar);
}
