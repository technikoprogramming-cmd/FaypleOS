package i;

import android.content.Context;
import android.view.View;
import android.view.Window;
import h.C0037a;

public final class d1 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final C0037a f1228a;
    public final /* synthetic */ e1 b;

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, h.a] */
    public d1(e1 e1Var) {
        this.b = e1Var;
        Context context = e1Var.f1229a.getContext();
        CharSequence charSequence = e1Var.f1234h;
        ? obj = new Object();
        obj.f978e = 4096;
        obj.f979g = 4096;
        obj.f984l = null;
        obj.f985m = null;
        obj.f986n = false;
        obj.f987o = false;
        obj.f988p = 16;
        obj.f981i = context;
        obj.f975a = charSequence;
        this.f1228a = obj;
    }

    public final void onClick(View view) {
        e1 e1Var = this.b;
        Window.Callback callback = e1Var.f1237k;
        if (callback != null && e1Var.f1238l) {
            callback.onMenuItemSelected(0, this.f1228a);
        }
    }
}
