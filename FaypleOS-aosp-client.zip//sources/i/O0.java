package i;

import android.content.res.Resources;

public abstract class O0 extends Resources {
}
