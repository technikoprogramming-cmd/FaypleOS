package i;

/* renamed from: i.m  reason: case insensitive filesystem */
public interface C0071m {
    boolean a();

    boolean b();
}
