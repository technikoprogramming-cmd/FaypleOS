package i;

import D.m;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

public final class P extends View.BaseSavedState {
    public static final Parcelable.Creator<P> CREATOR = new m(8);

    /* renamed from: a  reason: collision with root package name */
    public boolean f1170a;

    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeByte(this.f1170a ? (byte) 1 : 0);
    }
}
