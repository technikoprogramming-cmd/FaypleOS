package i;

import D.g;
import D.o;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import d.C0009a;
import h.D;
import java.lang.reflect.Method;

public abstract class G0 implements D {

    /* renamed from: A  reason: collision with root package name */
    public static final Method f1117A;

    /* renamed from: z  reason: collision with root package name */
    public static final Method f1118z;

    /* renamed from: a  reason: collision with root package name */
    public final Context f1119a;
    public ListAdapter b;

    /* renamed from: c  reason: collision with root package name */
    public C0085t0 f1120c;

    /* renamed from: d  reason: collision with root package name */
    public final int f1121d = -2;

    /* renamed from: e  reason: collision with root package name */
    public int f1122e = -2;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public int f1123g;

    /* renamed from: h  reason: collision with root package name */
    public final int f1124h = 1002;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1125i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1126j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f1127k;

    /* renamed from: l  reason: collision with root package name */
    public int f1128l = 0;

    /* renamed from: m  reason: collision with root package name */
    public final int f1129m = Integer.MAX_VALUE;

    /* renamed from: n  reason: collision with root package name */
    public D0 f1130n;

    /* renamed from: o  reason: collision with root package name */
    public View f1131o;

    /* renamed from: p  reason: collision with root package name */
    public AdapterView.OnItemClickListener f1132p;

    /* renamed from: q  reason: collision with root package name */
    public final C0 f1133q = new C0(this, 1);

    /* renamed from: r  reason: collision with root package name */
    public final F0 f1134r = new F0(this);

    /* renamed from: s  reason: collision with root package name */
    public final E0 f1135s = new E0(this);

    /* renamed from: t  reason: collision with root package name */
    public final C0 f1136t = new C0(this, 0);

    /* renamed from: u  reason: collision with root package name */
    public final Handler f1137u;

    /* renamed from: v  reason: collision with root package name */
    public final Rect f1138v = new Rect();

    /* renamed from: w  reason: collision with root package name */
    public Rect f1139w;

    /* renamed from: x  reason: collision with root package name */
    public boolean f1140x;

    /* renamed from: y  reason: collision with root package name */
    public final C0046D f1141y;

    static {
        Class<PopupWindow> cls = PopupWindow.class;
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f1118z = cls.getDeclaredMethod("setClipToScreenEnabled", new Class[]{Boolean.TYPE});
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f1117A = cls.getDeclaredMethod("setEpicenterBounds", new Class[]{Rect.class});
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    /* JADX WARNING: type inference failed for: r1v9, types: [android.widget.PopupWindow, i.D] */
    public G0(Context context, AttributeSet attributeSet, int i2) {
        Drawable drawable;
        int resourceId;
        this.f1119a = context;
        this.f1137u = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0009a.f707o, i2, 0);
        this.f = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f1123g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f1125i = true;
        }
        obtainStyledAttributes.recycle();
        ? popupWindow = new PopupWindow(context, attributeSet, i2, 0);
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, C0009a.f711s, i2, 0);
        if (obtainStyledAttributes2.hasValue(2)) {
            o.c(popupWindow, obtainStyledAttributes2.getBoolean(2, false));
        }
        if (!obtainStyledAttributes2.hasValue(0) || (resourceId = obtainStyledAttributes2.getResourceId(0, 0)) == 0) {
            drawable = obtainStyledAttributes2.getDrawable(0);
        } else {
            drawable = g.s(context, resourceId);
        }
        popupWindow.setBackgroundDrawable(drawable);
        obtainStyledAttributes2.recycle();
        this.f1141y = popupWindow;
        popupWindow.setInputMethodMode(1);
    }

    public final boolean a() {
        return this.f1141y.isShowing();
    }

    public final void c(int i2) {
        this.f = i2;
    }

    public final int d() {
        return this.f;
    }

    public final void dismiss() {
        C0046D d2 = this.f1141y;
        d2.dismiss();
        d2.setContentView((View) null);
        this.f1120c = null;
        this.f1137u.removeCallbacks(this.f1133q);
    }

    public final C0085t0 f() {
        return this.f1120c;
    }

    public final void h() {
        int i2;
        boolean z2;
        int i3;
        boolean z3;
        C0085t0 t0Var;
        int i4;
        int i5;
        int i6;
        int i7;
        C0085t0 t0Var2 = this.f1120c;
        C0046D d2 = this.f1141y;
        Context context = this.f1119a;
        if (t0Var2 == null) {
            C0085t0 o2 = o(context, !this.f1140x);
            this.f1120c = o2;
            o2.setAdapter(this.b);
            this.f1120c.setOnItemClickListener(this.f1132p);
            this.f1120c.setFocusable(true);
            this.f1120c.setFocusableInTouchMode(true);
            this.f1120c.setOnItemSelectedListener(new C0097z0(this));
            this.f1120c.setOnScrollListener(this.f1135s);
            d2.setContentView(this.f1120c);
        } else {
            ViewGroup viewGroup = (ViewGroup) d2.getContentView();
        }
        Drawable background = d2.getBackground();
        int i8 = 0;
        Rect rect = this.f1138v;
        if (background != null) {
            background.getPadding(rect);
            int i9 = rect.top;
            i2 = rect.bottom + i9;
            if (!this.f1125i) {
                this.f1123g = -i9;
            }
        } else {
            rect.setEmpty();
            i2 = 0;
        }
        if (d2.getInputMethodMode() == 2) {
            z2 = true;
        } else {
            z2 = false;
        }
        int a2 = A0.a(d2, this.f1131o, this.f1123g, z2);
        int i10 = this.f1121d;
        if (i10 == -1) {
            i3 = a2 + i2;
        } else {
            int i11 = this.f1122e;
            if (i11 == -2) {
                i6 = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE);
            } else if (i11 != -1) {
                i6 = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
            } else {
                i6 = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824);
            }
            int a3 = this.f1120c.a(i6, a2);
            if (a3 > 0) {
                i7 = this.f1120c.getPaddingBottom() + this.f1120c.getPaddingTop() + i2;
            } else {
                i7 = 0;
            }
            i3 = a3 + i7;
        }
        if (this.f1141y.getInputMethodMode() == 2) {
            z3 = true;
        } else {
            z3 = false;
        }
        o.d(d2, this.f1124h);
        if (!d2.isShowing()) {
            int i12 = this.f1122e;
            if (i12 == -1) {
                i12 = -1;
            } else if (i12 == -2) {
                i12 = this.f1131o.getWidth();
            }
            if (i10 == -1) {
                i10 = -1;
            } else if (i10 == -2) {
                i10 = i3;
            }
            d2.setWidth(i12);
            d2.setHeight(i10);
            if (Build.VERSION.SDK_INT <= 28) {
                Method method = f1118z;
                if (method != null) {
                    try {
                        method.invoke(d2, new Object[]{Boolean.TRUE});
                    } catch (Exception unused) {
                        Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                    }
                }
            } else {
                B0.b(d2, true);
            }
            d2.setOutsideTouchable(true);
            d2.setTouchInterceptor(this.f1134r);
            if (this.f1127k) {
                o.c(d2, this.f1126j);
            }
            if (Build.VERSION.SDK_INT <= 28) {
                Method method2 = f1117A;
                if (method2 != null) {
                    try {
                        method2.invoke(d2, new Object[]{this.f1139w});
                    } catch (Exception e2) {
                        Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                    }
                }
            } else {
                B0.a(d2, this.f1139w);
            }
            d2.showAsDropDown(this.f1131o, this.f, this.f1123g, this.f1128l);
            this.f1120c.setSelection(-1);
            if ((!this.f1140x || this.f1120c.isInTouchMode()) && (t0Var = this.f1120c) != null) {
                t0Var.setListSelectionHidden(true);
                t0Var.requestLayout();
            }
            if (!this.f1140x) {
                this.f1137u.post(this.f1136t);
            }
        } else if (this.f1131o.isAttachedToWindow()) {
            int i13 = this.f1122e;
            if (i13 == -1) {
                i13 = -1;
            } else if (i13 == -2) {
                i13 = this.f1131o.getWidth();
            }
            if (i10 == -1) {
                if (z3) {
                    i10 = i3;
                } else {
                    i10 = -1;
                }
                if (z3) {
                    if (this.f1122e == -1) {
                        i5 = -1;
                    } else {
                        i5 = 0;
                    }
                    d2.setWidth(i5);
                    d2.setHeight(0);
                } else {
                    if (this.f1122e == -1) {
                        i8 = -1;
                    }
                    d2.setWidth(i8);
                    d2.setHeight(-1);
                }
            } else if (i10 == -2) {
                i10 = i3;
            }
            d2.setOutsideTouchable(true);
            View view = this.f1131o;
            int i14 = this.f;
            int i15 = this.f1123g;
            if (i13 < 0) {
                i13 = -1;
            }
            if (i10 < 0) {
                i4 = -1;
            } else {
                i4 = i10;
            }
            d2.update(view, i14, i15, i13, i4);
        }
    }

    public final int i() {
        if (!this.f1125i) {
            return 0;
        }
        return this.f1123g;
    }

    public final void j(Drawable drawable) {
        this.f1141y.setBackgroundDrawable(drawable);
    }

    public final void k(int i2) {
        this.f1123g = i2;
        this.f1125i = true;
    }

    public final Drawable l() {
        return this.f1141y.getBackground();
    }

    public void m(ListAdapter listAdapter) {
        D0 d02 = this.f1130n;
        if (d02 == null) {
            this.f1130n = new D0(this);
        } else {
            ListAdapter listAdapter2 = this.b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(d02);
            }
        }
        this.b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f1130n);
        }
        C0085t0 t0Var = this.f1120c;
        if (t0Var != null) {
            t0Var.setAdapter(this.b);
        }
    }

    public C0085t0 o(Context context, boolean z2) {
        return new C0085t0(context, z2);
    }

    public final void p(int i2) {
        Drawable background = this.f1141y.getBackground();
        if (background != null) {
            Rect rect = this.f1138v;
            background.getPadding(rect);
            this.f1122e = rect.left + rect.right + i2;
            return;
        }
        this.f1122e = i2;
    }
}
