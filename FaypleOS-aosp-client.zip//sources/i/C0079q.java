package i;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import d.C0009a;
import java.util.WeakHashMap;
import y.A;
import y.K;

/* renamed from: i.q  reason: case insensitive filesystem */
public final class C0079q {

    /* renamed from: a  reason: collision with root package name */
    public final View f1311a;
    public final C0088v b;

    /* renamed from: c  reason: collision with root package name */
    public int f1312c = -1;

    /* renamed from: d  reason: collision with root package name */
    public U0 f1313d;

    /* renamed from: e  reason: collision with root package name */
    public U0 f1314e;
    public U0 f;

    public C0079q(View view) {
        this.f1311a = view;
        this.b = C0088v.a();
    }

    /* JADX WARNING: type inference failed for: r2v5, types: [i.U0, java.lang.Object] */
    public final void a() {
        View view = this.f1311a;
        Drawable background = view.getBackground();
        if (background != null) {
            if (this.f1313d != null) {
                if (this.f == null) {
                    this.f = new Object();
                }
                U0 u0 = this.f;
                u0.f1193a = null;
                u0.f1195d = false;
                u0.b = null;
                u0.f1194c = false;
                WeakHashMap weakHashMap = K.f1547a;
                ColorStateList g2 = A.g(view);
                if (g2 != null) {
                    u0.f1195d = true;
                    u0.f1193a = g2;
                }
                PorterDuff.Mode h2 = A.h(view);
                if (h2 != null) {
                    u0.f1194c = true;
                    u0.b = h2;
                }
                if (u0.f1195d || u0.f1194c) {
                    C0088v.d(background, u0, view.getDrawableState());
                    return;
                }
            }
            U0 u02 = this.f1314e;
            if (u02 != null) {
                C0088v.d(background, u02, view.getDrawableState());
                return;
            }
            U0 u03 = this.f1313d;
            if (u03 != null) {
                C0088v.d(background, u03, view.getDrawableState());
            }
        }
    }

    public final ColorStateList b() {
        U0 u0 = this.f1314e;
        if (u0 != null) {
            return u0.f1193a;
        }
        return null;
    }

    public final PorterDuff.Mode c() {
        U0 u0 = this.f1314e;
        if (u0 != null) {
            return u0.b;
        }
        return null;
    }

    public final void d(AttributeSet attributeSet, int i2) {
        ColorStateList f2;
        View view = this.f1311a;
        Context context = view.getContext();
        int[] iArr = C0009a.f717y;
        h p2 = h.p(context, attributeSet, iArr, i2);
        TypedArray typedArray = (TypedArray) p2.b;
        View view2 = this.f1311a;
        K.g(view2, view2.getContext(), iArr, attributeSet, (TypedArray) p2.b, i2);
        try {
            if (typedArray.hasValue(0)) {
                this.f1312c = typedArray.getResourceId(0, -1);
                C0088v vVar = this.b;
                Context context2 = view.getContext();
                int i3 = this.f1312c;
                synchronized (vVar) {
                    f2 = vVar.f1340a.f(context2, i3);
                }
                if (f2 != null) {
                    g(f2);
                }
            }
            if (typedArray.hasValue(1)) {
                A.q(view, p2.j(1));
            }
            if (typedArray.hasValue(2)) {
                A.r(view, C0074n0.b(typedArray.getInt(2, -1), (PorterDuff.Mode) null));
            }
            p2.r();
        } catch (Throwable th) {
            Throwable th2 = th;
            p2.r();
            throw th2;
        }
    }

    public final void e() {
        this.f1312c = -1;
        g((ColorStateList) null);
        a();
    }

    public final void f(int i2) {
        ColorStateList colorStateList;
        this.f1312c = i2;
        C0088v vVar = this.b;
        if (vVar != null) {
            Context context = this.f1311a.getContext();
            synchronized (vVar) {
                colorStateList = vVar.f1340a.f(context, i2);
            }
        } else {
            colorStateList = null;
        }
        g(colorStateList);
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.U0, java.lang.Object] */
    public final void g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f1313d == null) {
                this.f1313d = new Object();
            }
            U0 u0 = this.f1313d;
            u0.f1193a = colorStateList;
            u0.f1195d = true;
        } else {
            this.f1313d = null;
        }
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.U0, java.lang.Object] */
    public final void h(ColorStateList colorStateList) {
        if (this.f1314e == null) {
            this.f1314e = new Object();
        }
        U0 u0 = this.f1314e;
        u0.f1193a = colorStateList;
        u0.f1195d = true;
        a();
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.U0, java.lang.Object] */
    public final void i(PorterDuff.Mode mode) {
        if (this.f1314e == null) {
            this.f1314e = new Object();
        }
        U0 u0 = this.f1314e;
        u0.b = mode;
        u0.f1194c = true;
        a();
    }
}
