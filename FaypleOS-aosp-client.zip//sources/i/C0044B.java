package i;

import D.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: i.B  reason: case insensitive filesystem */
public class C0044B extends ImageView {

    /* renamed from: a  reason: collision with root package name */
    public final C0079q f1102a;
    public final C0043A b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1103c = false;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0044B(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        T0.a(context);
        S0.a(this, getContext());
        C0079q qVar = new C0079q(this);
        this.f1102a = qVar;
        qVar.d(attributeSet, i2);
        C0043A a2 = new C0043A(this);
        this.b = a2;
        a2.b(attributeSet, i2);
    }

    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            qVar.a();
        }
        C0043A a2 = this.b;
        if (a2 != null) {
            a2.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            return qVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            return qVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        U0 u0;
        C0043A a2 = this.b;
        if (a2 == null || (u0 = a2.b) == null) {
            return null;
        }
        return u0.f1193a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        U0 u0;
        C0043A a2 = this.b;
        if (a2 == null || (u0 = a2.b) == null) {
            return null;
        }
        return u0.b;
    }

    public final boolean hasOverlappingRendering() {
        if ((this.b.f1100a.getBackground() instanceof RippleDrawable) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            qVar.e();
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            qVar.f(i2);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0043A a2 = this.b;
        if (a2 != null) {
            a2.a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        C0043A a2 = this.b;
        if (!(a2 == null || drawable == null || this.f1103c)) {
            a2.f1101c = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (a2 != null) {
            a2.a();
            if (!this.f1103c) {
                ImageView imageView = a2.f1100a;
                if (imageView.getDrawable() != null) {
                    imageView.getDrawable().setLevel(a2.f1101c);
                }
            }
        }
    }

    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f1103c = true;
    }

    public void setImageResource(int i2) {
        C0043A a2 = this.b;
        if (a2 != null) {
            ImageView imageView = a2.f1100a;
            if (i2 != 0) {
                Drawable s2 = g.s(imageView.getContext(), i2);
                if (s2 != null) {
                    C0074n0.a(s2);
                }
                imageView.setImageDrawable(s2);
            } else {
                imageView.setImageDrawable((Drawable) null);
            }
            a2.a();
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0043A a2 = this.b;
        if (a2 != null) {
            a2.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            qVar.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q qVar = this.f1102a;
        if (qVar != null) {
            qVar.i(mode);
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [i.U0, java.lang.Object] */
    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0043A a2 = this.b;
        if (a2 != null) {
            if (a2.b == null) {
                a2.b = new Object();
            }
            U0 u0 = a2.b;
            u0.f1193a = colorStateList;
            u0.f1195d = true;
            a2.a();
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [i.U0, java.lang.Object] */
    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0043A a2 = this.b;
        if (a2 != null) {
            if (a2.b == null) {
                a2.b = new Object();
            }
            U0 u0 = a2.b;
            u0.b = mode;
            u0.f1194c = true;
            a2.a();
        }
    }
}
