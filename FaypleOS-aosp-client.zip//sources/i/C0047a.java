package i;

import androidx.appcompat.widget.ActionBarContextView;
import y.S;

/* renamed from: i.a  reason: case insensitive filesystem */
public final class C0047a implements S {

    /* renamed from: a  reason: collision with root package name */
    public boolean f1213a = false;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f1214c;

    public C0047a(ActionBarContextView actionBarContextView) {
        this.f1214c = actionBarContextView;
    }

    public final void a() {
        if (!this.f1213a) {
            ActionBarContextView actionBarContextView = this.f1214c;
            actionBarContextView.f = null;
            C0047a.super.setVisibility(this.b);
        }
    }

    public final void b() {
        this.f1213a = true;
    }

    public final void c() {
        C0047a.super.setVisibility(0);
        this.f1213a = false;
    }
}
