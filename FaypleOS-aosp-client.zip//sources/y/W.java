package y;

public final class W extends V {
    public W() {
    }

    public W(f0 f0Var) {
        super(f0Var);
    }
}
