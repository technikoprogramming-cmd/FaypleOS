package y;

import r.C0136c;

public abstract class X {
    public X() {
        this(new f0());
    }

    public abstract f0 b();

    public abstract void c(C0136c cVar);

    public abstract void d(C0136c cVar);

    public X(f0 f0Var) {
    }

    public final void a() {
    }
}
