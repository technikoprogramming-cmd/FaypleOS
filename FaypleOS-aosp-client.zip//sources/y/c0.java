package y;

import android.view.View;
import android.view.WindowInsets;
import r.C0136c;

public final class c0 extends b0 {

    /* renamed from: q  reason: collision with root package name */
    public static final f0 f1578q = f0.c(WindowInsets.CONSUMED, (View) null);

    public c0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public C0136c f(int i2) {
        return C0136c.b(this.f1567c.getInsets(e0.a(i2)));
    }

    public final void d(View view) {
    }
}
