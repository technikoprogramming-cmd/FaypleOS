package y;

import android.view.View;
import android.view.WindowInsets;
import r.C0136c;

public class b0 extends a0 {

    /* renamed from: n  reason: collision with root package name */
    public C0136c f1575n = null;

    /* renamed from: o  reason: collision with root package name */
    public C0136c f1576o = null;

    /* renamed from: p  reason: collision with root package name */
    public C0136c f1577p = null;

    public b0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public C0136c g() {
        if (this.f1576o == null) {
            this.f1576o = C0136c.b(this.f1567c.getMandatorySystemGestureInsets());
        }
        return this.f1576o;
    }

    public C0136c i() {
        if (this.f1575n == null) {
            this.f1575n = C0136c.b(this.f1567c.getSystemGestureInsets());
        }
        return this.f1575n;
    }

    public C0136c k() {
        if (this.f1577p == null) {
            this.f1577p = C0136c.b(this.f1567c.getTappableElementInsets());
        }
        return this.f1577p;
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        return f0.c(this.f1567c.inset(i2, i3, i4, i5), (View) null);
    }

    public void q(C0136c cVar) {
    }
}
