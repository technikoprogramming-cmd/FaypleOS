package y;

/* renamed from: y.u  reason: case insensitive filesystem */
public final class C0176u {

    /* renamed from: a  reason: collision with root package name */
    public final float[] f1598a = new float[20];
    public final long[] b = new long[20];

    /* renamed from: c  reason: collision with root package name */
    public float f1599c = 0.0f;

    /* renamed from: d  reason: collision with root package name */
    public int f1600d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f1601e = 0;
}
