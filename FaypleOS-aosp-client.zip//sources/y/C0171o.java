package y;

import androidx.core.widget.NestedScrollView;

/* renamed from: y.o  reason: case insensitive filesystem */
public interface C0171o extends C0170n {
    void d(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
