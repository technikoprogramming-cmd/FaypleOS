package y;

import android.view.DisplayCutout;
import java.util.Objects;

/* renamed from: y.j  reason: case insensitive filesystem */
public final class C0166j {

    /* renamed from: a  reason: collision with root package name */
    public final DisplayCutout f1592a;

    public C0166j(DisplayCutout displayCutout) {
        this.f1592a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0166j.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f1592a, ((C0166j) obj).f1592a);
    }

    public final int hashCode() {
        return this.f1592a.hashCode();
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f1592a + "}";
    }
}
