package y;

import C.j;
import D.u;
import android.view.ContentInfo;
import android.view.OnReceiveContentListener;
import android.view.View;
import java.util.Objects;

public final class H implements OnReceiveContentListener {

    /* renamed from: a  reason: collision with root package name */
    public final C0173q f1543a;

    public H(C0173q qVar) {
        this.f1543a = qVar;
    }

    public final ContentInfo onReceiveContent(View view, ContentInfo contentInfo) {
        C0163g gVar = new C0163g(new j(contentInfo));
        C0163g a2 = ((u) this.f1543a).a(view, gVar);
        if (a2 == null) {
            return null;
        }
        if (a2 == gVar) {
            return contentInfo;
        }
        ContentInfo s2 = a2.f1585a.s();
        Objects.requireNonNull(s2);
        return C0159c.e(s2);
    }
}
