package y;

import android.view.KeyEvent;

/* renamed from: y.k  reason: case insensitive filesystem */
public interface C0167k {
    boolean d(KeyEvent keyEvent);
}
