package y;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: y.t  reason: case insensitive filesystem */
public abstract class C0175t {

    /* renamed from: a  reason: collision with root package name */
    public static final Map f1597a = Collections.synchronizedMap(new WeakHashMap());
}
