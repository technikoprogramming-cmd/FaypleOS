package y;

/* renamed from: y.g  reason: case insensitive filesystem */
public final class C0163g {

    /* renamed from: a  reason: collision with root package name */
    public final C0162f f1585a;

    public C0163g(C0162f fVar) {
        this.f1585a = fVar;
    }

    public final String toString() {
        return this.f1585a.toString();
    }
}
