package y;

import android.content.ClipData;
import android.view.ContentInfo;

/* renamed from: y.c  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0159c {
    public static /* synthetic */ ContentInfo.Builder c(ClipData clipData, int i2) {
        return new ContentInfo.Builder(clipData, i2);
    }

    public static /* bridge */ /* synthetic */ ContentInfo e(Object obj) {
        return (ContentInfo) obj;
    }
}
