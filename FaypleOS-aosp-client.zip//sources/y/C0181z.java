package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.WeakHashMap;

/* renamed from: y.z  reason: case insensitive filesystem */
public final class C0181z implements View.OnApplyWindowInsetsListener {

    /* renamed from: a  reason: collision with root package name */
    public f0 f1604a = null;
    public final /* synthetic */ View b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0172p f1605c;

    public C0181z(View view, C0172p pVar) {
        this.b = view;
        this.f1605c = pVar;
    }

    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        f0 c2 = f0.c(windowInsets, view);
        int i2 = Build.VERSION.SDK_INT;
        C0172p pVar = this.f1605c;
        if (i2 < 30) {
            A.a(windowInsets, this.b);
            if (c2.equals(this.f1604a)) {
                return pVar.a(view, c2).b();
            }
        }
        this.f1604a = c2;
        f0 a2 = pVar.a(view, c2);
        if (i2 >= 30) {
            return a2.b();
        }
        WeakHashMap weakHashMap = K.f1547a;
        C0180y.c(view);
        return a2.b();
    }
}
