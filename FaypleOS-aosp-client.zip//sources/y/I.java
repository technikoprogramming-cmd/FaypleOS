package y;

public interface I {
}
