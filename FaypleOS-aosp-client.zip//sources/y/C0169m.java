package y;

import android.util.Log;
import android.view.ViewParent;
import androidx.core.widget.NestedScrollView;

/* renamed from: y.m  reason: case insensitive filesystem */
public final class C0169m {

    /* renamed from: a  reason: collision with root package name */
    public ViewParent f1593a;
    public ViewParent b;

    /* renamed from: c  reason: collision with root package name */
    public final NestedScrollView f1594c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1595d;

    /* renamed from: e  reason: collision with root package name */
    public int[] f1596e;

    public C0169m(NestedScrollView nestedScrollView) {
        this.f1594c = nestedScrollView;
    }

    public final boolean a(float f, float f2) {
        ViewParent c2;
        if (this.f1595d && (c2 = c(0)) != null) {
            try {
                return O.b(c2, this.f1594c, f, f2);
            } catch (AbstractMethodError e2) {
                Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedPreFling", e2);
            }
        }
        return false;
    }

    public final boolean b(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        ViewParent c2;
        int i7;
        int i8;
        int[] iArr3;
        int[] iArr4 = iArr;
        int i9 = i6;
        if (this.f1595d && (c2 = c(i9)) != null) {
            if (i2 != 0 || i3 != 0 || i4 != 0 || i5 != 0) {
                NestedScrollView nestedScrollView = this.f1594c;
                if (iArr4 != null) {
                    nestedScrollView.getLocationInWindow(iArr4);
                    i8 = iArr4[0];
                    i7 = iArr4[1];
                } else {
                    i8 = 0;
                    i7 = 0;
                }
                if (iArr2 == null) {
                    if (this.f1596e == null) {
                        this.f1596e = new int[2];
                    }
                    int[] iArr5 = this.f1596e;
                    iArr5[0] = 0;
                    iArr5[1] = 0;
                    iArr3 = iArr5;
                } else {
                    iArr3 = iArr2;
                }
                if (c2 instanceof C0171o) {
                    ((C0171o) c2).d(nestedScrollView, i2, i3, i4, i5, i9, iArr3);
                } else {
                    iArr3[0] = iArr3[0] + i4;
                    iArr3[1] = iArr3[1] + i5;
                    if (c2 instanceof C0170n) {
                        ((C0170n) c2).e(nestedScrollView, i2, i3, i4, i5, i6);
                    } else if (i6 == 0) {
                        try {
                            O.d(c2, nestedScrollView, i2, i3, i4, i5);
                        } catch (AbstractMethodError e2) {
                            Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedScroll", e2);
                        }
                    }
                }
                if (iArr4 != null) {
                    nestedScrollView.getLocationInWindow(iArr4);
                    iArr4[0] = iArr4[0] - i8;
                    iArr4[1] = iArr4[1] - i7;
                }
                return true;
            } else if (iArr4 != null) {
                iArr4[0] = 0;
                iArr4[1] = 0;
                return false;
            }
        }
        return false;
    }

    public final ViewParent c(int i2) {
        if (i2 == 0) {
            return this.f1593a;
        }
        if (i2 != 1) {
            return null;
        }
        return this.b;
    }
}
