package y;

import android.view.KeyEvent;
import android.view.View;

public final /* synthetic */ class C implements View.OnUnhandledKeyEventListener {
    public final boolean onUnhandledKeyEvent(View view, KeyEvent keyEvent) {
        throw null;
    }
}
