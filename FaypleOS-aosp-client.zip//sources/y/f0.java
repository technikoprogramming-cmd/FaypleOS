package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;
import java.util.WeakHashMap;
import r.C0136c;

public final class f0 {
    public static final f0 b;

    /* renamed from: a  reason: collision with root package name */
    public final d0 f1584a;

    static {
        if (Build.VERSION.SDK_INT >= 30) {
            b = c0.f1578q;
        } else {
            b = d0.b;
        }
    }

    public f0(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            this.f1584a = new c0(this, windowInsets);
        } else if (i2 >= 29) {
            this.f1584a = new b0(this, windowInsets);
        } else if (i2 >= 28) {
            this.f1584a = new a0(this, windowInsets);
        } else {
            this.f1584a = new Z(this, windowInsets);
        }
    }

    public static C0136c a(C0136c cVar, int i2, int i3, int i4, int i5) {
        int max = Math.max(0, cVar.f1500a - i2);
        int max2 = Math.max(0, cVar.b - i3);
        int max3 = Math.max(0, cVar.f1501c - i4);
        int max4 = Math.max(0, cVar.f1502d - i5);
        if (max == i2 && max2 == i3 && max3 == i4 && max4 == i5) {
            return cVar;
        }
        return C0136c.a(max, max2, max3, max4);
    }

    public static f0 c(WindowInsets windowInsets, View view) {
        windowInsets.getClass();
        f0 f0Var = new f0(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            WeakHashMap weakHashMap = K.f1547a;
            f0 a2 = B.a(view);
            d0 d0Var = f0Var.f1584a;
            d0Var.p(a2);
            d0Var.d(view.getRootView());
        }
        return f0Var;
    }

    public final WindowInsets b() {
        d0 d0Var = this.f1584a;
        if (d0Var instanceof Y) {
            return ((Y) d0Var).f1567c;
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f0)) {
            return false;
        }
        return Objects.equals(this.f1584a, ((f0) obj).f1584a);
    }

    public final int hashCode() {
        d0 d0Var = this.f1584a;
        if (d0Var == null) {
            return 0;
        }
        return d0Var.hashCode();
    }

    public f0() {
        this.f1584a = new d0(this);
    }
}
