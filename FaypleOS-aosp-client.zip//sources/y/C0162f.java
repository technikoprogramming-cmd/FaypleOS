package y;

import android.content.ClipData;
import android.view.ContentInfo;

/* renamed from: y.f  reason: case insensitive filesystem */
public interface C0162f {
    int f();

    ClipData j();

    int n();

    ContentInfo s();
}
