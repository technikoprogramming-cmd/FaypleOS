package y;

import android.view.View;

/* renamed from: y.p  reason: case insensitive filesystem */
public interface C0172p {
    f0 a(View view, f0 f0Var);
}
