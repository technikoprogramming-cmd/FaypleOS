package y;

import android.view.View;
import androidx.core.widget.NestedScrollView;

/* renamed from: y.n  reason: case insensitive filesystem */
public interface C0170n {
    void a(int i2, int i3, int[] iArr, int i4);

    void b(View view, View view2, int i2, int i3);

    void c(View view, int i2);

    void e(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6);

    boolean f(View view, View view2, int i2, int i3);
}
