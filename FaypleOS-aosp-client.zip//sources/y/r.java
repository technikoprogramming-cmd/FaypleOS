package y;

public interface r {
    C0163g a(C0163g gVar);
}
