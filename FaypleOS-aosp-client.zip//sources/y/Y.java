package y;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import r.C0136c;

public abstract class Y extends d0 {

    /* renamed from: h  reason: collision with root package name */
    public static boolean f1562h = false;

    /* renamed from: i  reason: collision with root package name */
    public static Method f1563i;

    /* renamed from: j  reason: collision with root package name */
    public static Class f1564j;

    /* renamed from: k  reason: collision with root package name */
    public static Field f1565k;

    /* renamed from: l  reason: collision with root package name */
    public static Field f1566l;

    /* renamed from: c  reason: collision with root package name */
    public final WindowInsets f1567c;

    /* renamed from: d  reason: collision with root package name */
    public C0136c[] f1568d;

    /* renamed from: e  reason: collision with root package name */
    public C0136c f1569e = null;
    public f0 f;

    /* renamed from: g  reason: collision with root package name */
    public C0136c f1570g;

    public Y(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var);
        this.f1567c = windowInsets;
    }

    private C0136c r(int i2, boolean z2) {
        C0136c cVar = C0136c.f1499e;
        for (int i3 = 1; i3 <= 256; i3 <<= 1) {
            if ((i2 & i3) != 0) {
                C0136c s2 = s(i3, z2);
                cVar = C0136c.a(Math.max(cVar.f1500a, s2.f1500a), Math.max(cVar.b, s2.b), Math.max(cVar.f1501c, s2.f1501c), Math.max(cVar.f1502d, s2.f1502d));
            }
        }
        return cVar;
    }

    private C0136c t() {
        f0 f0Var = this.f;
        if (f0Var != null) {
            return f0Var.f1584a.h();
        }
        return C0136c.f1499e;
    }

    private C0136c u(View view) {
        if (Build.VERSION.SDK_INT < 30) {
            if (!f1562h) {
                v();
            }
            Method method = f1563i;
            if (!(method == null || f1564j == null || f1565k == null)) {
                try {
                    Object invoke = method.invoke(view, (Object[]) null);
                    if (invoke == null) {
                        Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                        return null;
                    }
                    Rect rect = (Rect) f1565k.get(f1566l.get(invoke));
                    if (rect != null) {
                        return C0136c.a(rect.left, rect.top, rect.right, rect.bottom);
                    }
                } catch (ReflectiveOperationException e2) {
                    Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
                }
            }
            return null;
        }
        throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }

    private static void v() {
        try {
            f1563i = View.class.getDeclaredMethod("getViewRootImpl", (Class[]) null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f1564j = cls;
            f1565k = cls.getDeclaredField("mVisibleInsets");
            f1566l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f1565k.setAccessible(true);
            f1566l.setAccessible(true);
        } catch (ReflectiveOperationException e2) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
        }
        f1562h = true;
    }

    public void d(View view) {
        C0136c u2 = u(view);
        if (u2 == null) {
            u2 = C0136c.f1499e;
        }
        w(u2);
    }

    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        }
        return Objects.equals(this.f1570g, ((Y) obj).f1570g);
    }

    public C0136c f(int i2) {
        return r(i2, false);
    }

    public final C0136c j() {
        if (this.f1569e == null) {
            WindowInsets windowInsets = this.f1567c;
            this.f1569e = C0136c.a(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f1569e;
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        X x2;
        f0 c2 = f0.c(this.f1567c, (View) null);
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 30) {
            x2 = new W(c2);
        } else if (i6 >= 29) {
            x2 = new V(c2);
        } else {
            x2 = new U(c2);
        }
        x2.d(f0.a(j(), i2, i3, i4, i5));
        x2.c(f0.a(h(), i2, i3, i4, i5));
        return x2.b();
    }

    public boolean n() {
        return this.f1567c.isRound();
    }

    public void o(C0136c[] cVarArr) {
        this.f1568d = cVarArr;
    }

    public void p(f0 f0Var) {
        this.f = f0Var;
    }

    public C0136c s(int i2, boolean z2) {
        int i3;
        C0166j jVar;
        int i4;
        int i5;
        int i6;
        int i7 = 0;
        if (i2 != 1) {
            C0136c cVar = null;
            if (i2 != 2) {
                C0136c cVar2 = C0136c.f1499e;
                if (i2 == 8) {
                    C0136c[] cVarArr = this.f1568d;
                    if (cVarArr != null) {
                        cVar = cVarArr[3];
                    }
                    if (cVar != null) {
                        return cVar;
                    }
                    C0136c j2 = j();
                    C0136c t2 = t();
                    int i8 = j2.f1502d;
                    if (i8 > t2.f1502d) {
                        return C0136c.a(0, 0, 0, i8);
                    }
                    C0136c cVar3 = this.f1570g;
                    if (cVar3 != null && !cVar3.equals(cVar2) && (i3 = this.f1570g.f1502d) > t2.f1502d) {
                        return C0136c.a(0, 0, 0, i3);
                    }
                } else if (i2 == 16) {
                    return i();
                } else {
                    if (i2 == 32) {
                        return g();
                    }
                    if (i2 == 64) {
                        return k();
                    }
                    if (i2 == 128) {
                        f0 f0Var = this.f;
                        if (f0Var != null) {
                            jVar = f0Var.f1584a.e();
                        } else {
                            jVar = e();
                        }
                        if (jVar != null) {
                            int i9 = Build.VERSION.SDK_INT;
                            if (i9 >= 28) {
                                i4 = C0165i.d(jVar.f1592a);
                            } else {
                                i4 = 0;
                            }
                            if (i9 >= 28) {
                                i5 = C0165i.f(jVar.f1592a);
                            } else {
                                i5 = 0;
                            }
                            if (i9 >= 28) {
                                i6 = C0165i.e(jVar.f1592a);
                            } else {
                                i6 = 0;
                            }
                            if (i9 >= 28) {
                                i7 = C0165i.c(jVar.f1592a);
                            }
                            return C0136c.a(i4, i5, i6, i7);
                        }
                    }
                }
                return cVar2;
            } else if (z2) {
                C0136c t3 = t();
                C0136c h2 = h();
                return C0136c.a(Math.max(t3.f1500a, h2.f1500a), 0, Math.max(t3.f1501c, h2.f1501c), Math.max(t3.f1502d, h2.f1502d));
            } else {
                C0136c j3 = j();
                f0 f0Var2 = this.f;
                if (f0Var2 != null) {
                    cVar = f0Var2.f1584a.h();
                }
                int i10 = j3.f1502d;
                if (cVar != null) {
                    i10 = Math.min(i10, cVar.f1502d);
                }
                return C0136c.a(j3.f1500a, 0, j3.f1501c, i10);
            }
        } else if (z2) {
            return C0136c.a(0, Math.max(t().b, j().b), 0, 0);
        } else {
            return C0136c.a(0, j().b, 0, 0);
        }
    }

    public void w(C0136c cVar) {
        this.f1570g = cVar;
    }
}
