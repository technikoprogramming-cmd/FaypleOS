package y;

import android.view.View;
import android.view.WindowInsets;
import r.C0136c;

public class Z extends Y {

    /* renamed from: m  reason: collision with root package name */
    public C0136c f1571m = null;

    public Z(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public f0 b() {
        return f0.c(this.f1567c.consumeStableInsets(), (View) null);
    }

    public f0 c() {
        return f0.c(this.f1567c.consumeSystemWindowInsets(), (View) null);
    }

    public final C0136c h() {
        if (this.f1571m == null) {
            WindowInsets windowInsets = this.f1567c;
            this.f1571m = C0136c.a(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f1571m;
    }

    public boolean m() {
        return this.f1567c.isConsumed();
    }

    public void q(C0136c cVar) {
        this.f1571m = cVar;
    }
}
