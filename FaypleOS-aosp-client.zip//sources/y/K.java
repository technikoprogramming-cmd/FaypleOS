package y;

import D.u;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import i.C0092x;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import nikodem.faypleos.server.R;

public abstract class K {

    /* renamed from: a  reason: collision with root package name */
    public static WeakHashMap f1547a = null;
    public static Field b = null;

    /* renamed from: c  reason: collision with root package name */
    public static boolean f1548c = false;

    /* renamed from: d  reason: collision with root package name */
    public static final C0177v f1549d = new Object();

    /* renamed from: e  reason: collision with root package name */
    public static final C0179x f1550e = new C0179x();

    public static Q a(View view) {
        if (f1547a == null) {
            f1547a = new WeakHashMap();
        }
        Q q2 = (Q) f1547a.get(view);
        if (q2 != null) {
            return q2;
        }
        Q q3 = new Q(view);
        f1547a.put(view, q3);
        return q3;
    }

    /* JADX WARNING: type inference failed for: r1v5, types: [y.J, java.lang.Object] */
    public static boolean b(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        ArrayList arrayList = J.f1544d;
        J j2 = (J) view.getTag(R.id.tag_unhandled_key_event_manager);
        J j3 = j2;
        if (j2 == null) {
            ? obj = new Object();
            obj.f1545a = null;
            obj.b = null;
            obj.f1546c = null;
            view.setTag(R.id.tag_unhandled_key_event_manager, obj);
            j3 = obj;
        }
        if (keyEvent.getAction() == 0) {
            WeakHashMap weakHashMap = j3.f1545a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            ArrayList arrayList2 = J.f1544d;
            if (!arrayList2.isEmpty()) {
                synchronized (arrayList2) {
                    try {
                        if (j3.f1545a == null) {
                            j3.f1545a = new WeakHashMap();
                        }
                        for (int size = arrayList2.size() - 1; size >= 0; size--) {
                            ArrayList arrayList3 = J.f1544d;
                            View view2 = (View) ((WeakReference) arrayList3.get(size)).get();
                            if (view2 == null) {
                                arrayList3.remove(size);
                            } else {
                                j3.f1545a.put(view2, Boolean.TRUE);
                                for (ViewParent parent = view2.getParent(); parent instanceof View; parent = parent.getParent()) {
                                    j3.f1545a.put((View) parent, Boolean.TRUE);
                                }
                            }
                        }
                    } finally {
                    }
                }
            }
        }
        View a2 = j3.a(view);
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (a2 != null && !KeyEvent.isModifierKey(keyCode)) {
                if (j3.b == null) {
                    j3.b = new SparseArray();
                }
                j3.b.put(keyCode, new WeakReference(a2));
            }
        }
        if (a2 != null) {
            return true;
        }
        return false;
    }

    public static View.AccessibilityDelegate c(View view) {
        if (Build.VERSION.SDK_INT >= 29) {
            return E.a(view);
        }
        if (f1548c) {
            return null;
        }
        if (b == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                b = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f1548c = true;
                return null;
            }
        }
        try {
            Object obj = b.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f1548c = true;
            return null;
        }
    }

    public static String[] d(C0092x xVar) {
        if (Build.VERSION.SDK_INT >= 31) {
            return G.a(xVar);
        }
        return (String[]) xVar.getTag(R.id.tag_on_receive_content_mime_types);
    }

    public static void e(View view, int i2) {
        Object obj;
        boolean z2;
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            int i3 = Build.VERSION.SDK_INT;
            Object obj2 = null;
            Class<CharSequence> cls = CharSequence.class;
            if (i3 >= 28) {
                obj = D.b(view);
            } else {
                obj = view.getTag(R.id.tag_accessibility_pane_title);
                if (!cls.isInstance(obj)) {
                    obj = null;
                }
            }
            if (((CharSequence) obj) == null || !view.isShown() || view.getWindowVisibility() != 0) {
                z2 = false;
            } else {
                z2 = true;
            }
            int i4 = 32;
            if (view.getAccessibilityLiveRegion() != 0 || z2) {
                AccessibilityEvent obtain = AccessibilityEvent.obtain();
                if (!z2) {
                    i4 = 2048;
                }
                obtain.setEventType(i4);
                obtain.setContentChangeTypes(i2);
                if (z2) {
                    List<CharSequence> text = obtain.getText();
                    if (i3 >= 28) {
                        obj2 = D.b(view);
                    } else {
                        Object tag = view.getTag(R.id.tag_accessibility_pane_title);
                        if (cls.isInstance(tag)) {
                            obj2 = tag;
                        }
                    }
                    text.add((CharSequence) obj2);
                    if (view.getImportantForAccessibility() == 0) {
                        view.setImportantForAccessibility(1);
                    }
                }
                view.sendAccessibilityEventUnchecked(obtain);
            } else if (i2 == 32) {
                AccessibilityEvent obtain2 = AccessibilityEvent.obtain();
                view.onInitializeAccessibilityEvent(obtain2);
                obtain2.setEventType(32);
                obtain2.setContentChangeTypes(i2);
                obtain2.setSource(view);
                view.onPopulateAccessibilityEvent(obtain2);
                List<CharSequence> text2 = obtain2.getText();
                if (i3 >= 28) {
                    obj2 = D.b(view);
                } else {
                    Object tag2 = view.getTag(R.id.tag_accessibility_pane_title);
                    if (cls.isInstance(tag2)) {
                        obj2 = tag2;
                    }
                }
                text2.add((CharSequence) obj2);
                accessibilityManager.sendAccessibilityEvent(obtain2);
            } else if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i2);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewCompat", view.getParent().getClass().getSimpleName().concat(" does not fully implement ViewParent"), e2);
                }
            }
        }
    }

    public static C0163g f(View view, C0163g gVar) {
        if (Log.isLoggable("ViewCompat", 3)) {
            Log.d("ViewCompat", "performReceiveContent: " + gVar + ", view=" + view.getClass().getSimpleName() + "[" + view.getId() + "]");
        }
        if (Build.VERSION.SDK_INT >= 31) {
            return G.b(view, gVar);
        }
        C0173q qVar = (C0173q) view.getTag(R.id.tag_on_receive_content_listener);
        r rVar = f1549d;
        if (qVar != null) {
            C0163g a2 = ((u) qVar).a(view, gVar);
            if (a2 == null) {
                return null;
            }
            if (view instanceof r) {
                rVar = (r) view;
            }
            return rVar.a(a2);
        }
        if (view instanceof r) {
            rVar = (r) view;
        }
        return rVar.a(gVar);
    }

    public static void g(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2) {
        if (Build.VERSION.SDK_INT >= 29) {
            E.d(view, context, iArr, attributeSet, typedArray, i2, 0);
        }
    }

    public static void h(View view, C0158b bVar) {
        C0157a aVar;
        if (bVar == null && (c(view) instanceof C0157a)) {
            bVar = new C0158b();
        }
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
        }
        if (bVar == null) {
            aVar = null;
        } else {
            aVar = bVar.b;
        }
        view.setAccessibilityDelegate(aVar);
    }

    public static void i(View view, CharSequence charSequence) {
        boolean z2;
        new C0178w(R.id.tag_accessibility_pane_title, CharSequence.class, 8, 28, 1).d(view, charSequence);
        C0179x xVar = f1550e;
        if (charSequence != null) {
            WeakHashMap weakHashMap = xVar.f1603a;
            if (!view.isShown() || view.getWindowVisibility() != 0) {
                z2 = false;
            } else {
                z2 = true;
            }
            weakHashMap.put(view, Boolean.valueOf(z2));
            view.addOnAttachStateChangeListener(xVar);
            if (view.isAttachedToWindow()) {
                view.getViewTreeObserver().addOnGlobalLayoutListener(xVar);
                return;
            }
            return;
        }
        xVar.f1603a.remove(view);
        view.removeOnAttachStateChangeListener(xVar);
        view.getViewTreeObserver().removeOnGlobalLayoutListener(xVar);
    }
}
