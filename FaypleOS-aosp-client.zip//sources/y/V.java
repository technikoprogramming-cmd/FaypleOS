package y;

import N.a;
import android.view.View;
import android.view.WindowInsets;
import r.C0136c;

public class V extends X {

    /* renamed from: a  reason: collision with root package name */
    public final WindowInsets.Builder f1561a;

    public V() {
        this.f1561a = a.d();
    }

    public f0 b() {
        a();
        f0 c2 = f0.c(this.f1561a.build(), (View) null);
        c2.f1584a.o((C0136c[]) null);
        return c2;
    }

    public void c(C0136c cVar) {
        this.f1561a.setStableInsets(cVar.c());
    }

    public void d(C0136c cVar) {
        this.f1561a.setSystemWindowInsets(cVar.c());
    }

    public V(f0 f0Var) {
        super(f0Var);
        WindowInsets.Builder builder;
        WindowInsets b = f0Var.b();
        if (b != null) {
            builder = a.e(b);
        } else {
            builder = a.d();
        }
        this.f1561a = builder;
    }
}
