package y;

import C.j;
import android.content.Context;
import android.view.VelocityTracker;

/* renamed from: y.h  reason: case insensitive filesystem */
public final class C0164h {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1586a;
    public final j b;

    /* renamed from: c  reason: collision with root package name */
    public VelocityTracker f1587c;

    /* renamed from: d  reason: collision with root package name */
    public float f1588d;

    /* renamed from: e  reason: collision with root package name */
    public int f1589e = -1;
    public int f = -1;

    /* renamed from: g  reason: collision with root package name */
    public int f1590g = -1;

    /* renamed from: h  reason: collision with root package name */
    public final int[] f1591h = {Integer.MAX_VALUE, 0};

    public C0164h(Context context, j jVar) {
        this.f1586a = context;
        this.b = jVar;
    }
}
