package y;

/* renamed from: y.v  reason: case insensitive filesystem */
public final /* synthetic */ class C0177v implements r {
    public final C0163g a(C0163g gVar) {
        return gVar;
    }
}
