package y;

import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;

public class a0 extends Z {
    public a0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    public f0 a() {
        return f0.c(this.f1567c.consumeDisplayCutout(), (View) null);
    }

    public C0166j e() {
        DisplayCutout i2 = this.f1567c.getDisplayCutout();
        if (i2 == null) {
            return null;
        }
        return new C0166j(i2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a0)) {
            return false;
        }
        a0 a0Var = (a0) obj;
        if (!Objects.equals(this.f1567c, a0Var.f1567c) || !Objects.equals(this.f1570g, a0Var.f1570g)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.f1567c.hashCode();
    }
}
