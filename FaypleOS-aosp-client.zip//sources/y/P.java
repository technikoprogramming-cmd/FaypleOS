package y;

import C.j;
import android.animation.ValueAnimator;
import android.view.View;
import e.L;

public final /* synthetic */ class P implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j f1552a;

    public /* synthetic */ P(j jVar, View view) {
        this.f1552a = jVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        ((View) ((L) this.f1552a.b).f816r.getParent()).invalidate();
    }
}
