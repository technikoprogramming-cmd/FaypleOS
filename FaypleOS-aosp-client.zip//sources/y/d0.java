package y;

import android.os.Build;
import android.view.View;
import java.util.Objects;
import r.C0136c;

public class d0 {
    public static final f0 b;

    /* renamed from: a  reason: collision with root package name */
    public final f0 f1579a;

    static {
        X x2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            x2 = new W();
        } else if (i2 >= 29) {
            x2 = new V();
        } else {
            x2 = new U();
        }
        b = x2.b().f1584a.a().f1584a.b().f1584a.c();
    }

    public d0(f0 f0Var) {
        this.f1579a = f0Var;
    }

    public f0 a() {
        return this.f1579a;
    }

    public f0 b() {
        return this.f1579a;
    }

    public f0 c() {
        return this.f1579a;
    }

    public C0166j e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d0)) {
            return false;
        }
        d0 d0Var = (d0) obj;
        if (n() != d0Var.n() || m() != d0Var.m() || !Objects.equals(j(), d0Var.j()) || !Objects.equals(h(), d0Var.h()) || !Objects.equals(e(), d0Var.e())) {
            return false;
        }
        return true;
    }

    public C0136c f(int i2) {
        return C0136c.f1499e;
    }

    public C0136c g() {
        return j();
    }

    public C0136c h() {
        return C0136c.f1499e;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{Boolean.valueOf(n()), Boolean.valueOf(m()), j(), h(), e()});
    }

    public C0136c i() {
        return j();
    }

    public C0136c j() {
        return C0136c.f1499e;
    }

    public C0136c k() {
        return j();
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        return b;
    }

    public boolean m() {
        return false;
    }

    public boolean n() {
        return false;
    }

    public void d(View view) {
    }

    public void o(C0136c[] cVarArr) {
    }

    public void p(f0 f0Var) {
    }

    public void q(C0136c cVar) {
    }
}
