package h;

import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;
import g.C0026b;

public final class r extends FrameLayout implements C0026b {

    /* renamed from: a  reason: collision with root package name */
    public final CollapsibleActionView f1084a;

    public r(View view) {
        super(view.getContext());
        this.f1084a = (CollapsibleActionView) view;
        addView(view);
    }
}
