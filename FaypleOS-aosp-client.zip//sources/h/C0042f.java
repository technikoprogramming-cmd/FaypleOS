package h;

import C.j;

/* renamed from: h.f  reason: case insensitive filesystem */
public final class C0042f implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f993a;
    public final /* synthetic */ p b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ n f994c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ j f995d;

    public C0042f(j jVar, g gVar, p pVar, n nVar) {
        this.f995d = jVar;
        this.f993a = gVar;
        this.b = pVar;
        this.f994c = nVar;
    }

    public final void run() {
        g gVar = this.f993a;
        if (gVar != null) {
            j jVar = this.f995d;
            ((h) jVar.b).f1020z = true;
            gVar.b.c(false);
            ((h) jVar.b).f1020z = false;
        }
        p pVar = this.b;
        if (pVar.isEnabled() && pVar.hasSubMenu()) {
            this.f994c.q(pVar, (z) null, 4);
        }
    }
}
