package h;

import android.view.View;
import androidx.appcompat.view.menu.ActionMenuItemView;
import i.C0061h;
import i.C0063i;
import i.C0067k;
import i.C0069l;
import i.C0091w0;

/* renamed from: h.b  reason: case insensitive filesystem */
public final class C0038b extends C0091w0 {

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ int f989j = 0;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ View f990k;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0038b(ActionMenuItemView actionMenuItemView) {
        super(actionMenuItemView);
        this.f990k = actionMenuItemView;
    }

    public final D b() {
        C0061h hVar;
        switch (this.f989j) {
            case 0:
                C0039c cVar = ((ActionMenuItemView) this.f990k).f322m;
                if (cVar == null || (hVar = ((C0063i) cVar).f1255a.f1294t) == null) {
                    return null;
                }
                return hVar.a();
            default:
                C0061h hVar2 = ((C0067k) this.f990k).f1276d.f1293s;
                if (hVar2 == null) {
                    return null;
                }
                return hVar2.a();
        }
    }

    public final boolean c() {
        D b;
        switch (this.f989j) {
            case 0:
                ActionMenuItemView actionMenuItemView = (ActionMenuItemView) this.f990k;
                m mVar = actionMenuItemView.f320k;
                if (mVar == null || !mVar.b(actionMenuItemView.f317h) || (b = b()) == null || !b.a()) {
                    return false;
                }
                return true;
            default:
                ((C0067k) this.f990k).f1276d.l();
                return true;
        }
    }

    public boolean d() {
        switch (this.f989j) {
            case 1:
                C0069l lVar = ((C0067k) this.f990k).f1276d;
                if (lVar.f1295u != null) {
                    return false;
                }
                lVar.f();
                return true;
            default:
                return super.d();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0038b(C0067k kVar, C0067k kVar2) {
        super(kVar2);
        this.f990k = kVar;
    }
}
