package h;

import android.view.MenuItem;

public final class s implements MenuItem.OnActionExpandListener {

    /* renamed from: a  reason: collision with root package name */
    public final MenuItem.OnActionExpandListener f1085a;
    public final /* synthetic */ u b;

    public s(u uVar, MenuItem.OnActionExpandListener onActionExpandListener) {
        this.b = uVar;
        this.f1085a = onActionExpandListener;
    }

    public final boolean onMenuItemActionCollapse(MenuItem menuItem) {
        return this.f1085a.onMenuItemActionCollapse(this.b.f(menuItem));
    }

    public final boolean onMenuItemActionExpand(MenuItem menuItem) {
        return this.f1085a.onMenuItemActionExpand(this.b.f(menuItem));
    }
}
