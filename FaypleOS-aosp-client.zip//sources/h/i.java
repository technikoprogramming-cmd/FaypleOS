package h;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import nikodem.faypleos.server.R;

public final class i extends BaseAdapter {

    /* renamed from: a  reason: collision with root package name */
    public int f1021a = -1;
    public final /* synthetic */ j b;

    public i(j jVar) {
        this.b = jVar;
        a();
    }

    public final void a() {
        n nVar = this.b.f1023c;
        p pVar = nVar.f1050v;
        if (pVar != null) {
            nVar.i();
            ArrayList arrayList = nVar.f1038j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((p) arrayList.get(i2)) == pVar) {
                    this.f1021a = i2;
                    return;
                }
            }
        }
        this.f1021a = -1;
    }

    /* renamed from: b */
    public final p getItem(int i2) {
        j jVar = this.b;
        n nVar = jVar.f1023c;
        nVar.i();
        ArrayList arrayList = nVar.f1038j;
        jVar.getClass();
        int i3 = this.f1021a;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (p) arrayList.get(i2);
    }

    public final int getCount() {
        j jVar = this.b;
        n nVar = jVar.f1023c;
        nVar.i();
        int size = nVar.f1038j.size();
        jVar.getClass();
        if (this.f1021a < 0) {
            return size;
        }
        return size - 1;
    }

    public final long getItemId(int i2) {
        return (long) i2;
    }

    public final View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.b.b.inflate(R.layout.abc_list_menu_item_layout, viewGroup, false);
        }
        ((C0036A) view).c(getItem(i2));
        return view;
    }

    public final void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
