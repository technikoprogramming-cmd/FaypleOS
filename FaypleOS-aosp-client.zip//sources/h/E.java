package h;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import i.C0085t0;
import i.G0;
import i.L0;
import nikodem.faypleos.server.R;

public final class E extends v implements PopupWindow.OnDismissListener, View.OnKeyListener {
    public final Context b;

    /* renamed from: c  reason: collision with root package name */
    public final n f956c;

    /* renamed from: d  reason: collision with root package name */
    public final k f957d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f958e;
    public final int f;

    /* renamed from: g  reason: collision with root package name */
    public final int f959g;

    /* renamed from: h  reason: collision with root package name */
    public final L0 f960h;

    /* renamed from: i  reason: collision with root package name */
    public final C0040d f961i = new C0040d(1, this);

    /* renamed from: j  reason: collision with root package name */
    public final C0041e f962j = new C0041e(this, 1);

    /* renamed from: k  reason: collision with root package name */
    public w f963k;

    /* renamed from: l  reason: collision with root package name */
    public View f964l;

    /* renamed from: m  reason: collision with root package name */
    public View f965m;

    /* renamed from: n  reason: collision with root package name */
    public y f966n;

    /* renamed from: o  reason: collision with root package name */
    public ViewTreeObserver f967o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f968p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f969q;

    /* renamed from: r  reason: collision with root package name */
    public int f970r;

    /* renamed from: s  reason: collision with root package name */
    public int f971s = 0;

    /* renamed from: t  reason: collision with root package name */
    public boolean f972t;

    /* JADX WARNING: type inference failed for: r6v1, types: [i.L0, i.G0] */
    public E(int i2, Context context, View view, n nVar, boolean z2) {
        this.b = context;
        this.f956c = nVar;
        this.f958e = z2;
        this.f957d = new k(nVar, LayoutInflater.from(context), z2, R.layout.abc_popup_menu_item_layout);
        this.f959g = i2;
        Resources resources = context.getResources();
        this.f = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f964l = view;
        this.f960h = new G0(context, (AttributeSet) null, i2);
        nVar.b(this, context);
    }

    public final boolean a() {
        if (this.f968p || !this.f960h.f1141y.isShowing()) {
            return false;
        }
        return true;
    }

    public final void b(n nVar, boolean z2) {
        if (nVar == this.f956c) {
            dismiss();
            y yVar = this.f966n;
            if (yVar != null) {
                yVar.b(nVar, z2);
            }
        }
    }

    public final void c() {
        this.f969q = false;
        k kVar = this.f957d;
        if (kVar != null) {
            kVar.notifyDataSetChanged();
        }
    }

    public final void dismiss() {
        if (a()) {
            this.f960h.dismiss();
        }
    }

    public final void e(y yVar) {
        this.f966n = yVar;
    }

    public final C0085t0 f() {
        return this.f960h.f1120c;
    }

    public final void h() {
        View view;
        boolean z2;
        Rect rect;
        if (!a()) {
            if (this.f968p || (view = this.f964l) == null) {
                throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
            }
            this.f965m = view;
            L0 l0 = this.f960h;
            l0.f1141y.setOnDismissListener(this);
            l0.f1132p = this;
            l0.f1140x = true;
            l0.f1141y.setFocusable(true);
            View view2 = this.f965m;
            if (this.f967o == null) {
                z2 = true;
            } else {
                z2 = false;
            }
            ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
            this.f967o = viewTreeObserver;
            if (z2) {
                viewTreeObserver.addOnGlobalLayoutListener(this.f961i);
            }
            view2.addOnAttachStateChangeListener(this.f962j);
            l0.f1131o = view2;
            l0.f1128l = this.f971s;
            boolean z3 = this.f969q;
            Context context = this.b;
            k kVar = this.f957d;
            if (!z3) {
                this.f970r = v.m(kVar, context, this.f);
                this.f969q = true;
            }
            l0.p(this.f970r);
            l0.f1141y.setInputMethodMode(2);
            Rect rect2 = this.f1089a;
            if (rect2 != null) {
                rect = new Rect(rect2);
            } else {
                rect = null;
            }
            l0.f1139w = rect;
            l0.h();
            C0085t0 t0Var = l0.f1120c;
            t0Var.setOnKeyListener(this);
            if (this.f972t) {
                n nVar = this.f956c;
                if (nVar.f1041m != null) {
                    FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(context).inflate(R.layout.abc_popup_menu_header_item_layout, t0Var, false);
                    TextView textView = (TextView) frameLayout.findViewById(16908310);
                    if (textView != null) {
                        textView.setText(nVar.f1041m);
                    }
                    frameLayout.setEnabled(false);
                    t0Var.addHeaderView(frameLayout, (Object) null, false);
                }
            }
            l0.m(kVar);
            l0.h();
        }
    }

    public final boolean i() {
        return false;
    }

    public final boolean j(F f2) {
        if (f2.hasVisibleItems()) {
            View view = this.f965m;
            F f3 = f2;
            x xVar = new x(this.f959g, this.b, view, f3, this.f958e);
            y yVar = this.f966n;
            xVar.f1096h = yVar;
            v vVar = xVar.f1097i;
            if (vVar != null) {
                vVar.e(yVar);
            }
            boolean u2 = v.u(f3);
            xVar.f1095g = u2;
            v vVar2 = xVar.f1097i;
            if (vVar2 != null) {
                vVar2.o(u2);
            }
            xVar.f1098j = this.f963k;
            this.f963k = null;
            this.f956c.c(false);
            L0 l0 = this.f960h;
            int i2 = l0.f;
            int i3 = l0.i();
            if ((Gravity.getAbsoluteGravity(this.f971s, this.f964l.getLayoutDirection()) & 7) == 5) {
                i2 += this.f964l.getWidth();
            }
            if (!xVar.b()) {
                if (xVar.f1094e != null) {
                    xVar.d(i2, i3, true, true);
                }
            }
            y yVar2 = this.f966n;
            if (yVar2 != null) {
                yVar2.m(f3);
            }
            return true;
        }
        return false;
    }

    public final void n(View view) {
        this.f964l = view;
    }

    public final void o(boolean z2) {
        this.f957d.f1027c = z2;
    }

    public final void onDismiss() {
        this.f968p = true;
        this.f956c.c(true);
        ViewTreeObserver viewTreeObserver = this.f967o;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f967o = this.f965m.getViewTreeObserver();
            }
            this.f967o.removeGlobalOnLayoutListener(this.f961i);
            this.f967o = null;
        }
        this.f965m.removeOnAttachStateChangeListener(this.f962j);
        w wVar = this.f963k;
        if (wVar != null) {
            wVar.onDismiss();
        }
    }

    public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    public final void p(int i2) {
        this.f971s = i2;
    }

    public final void q(int i2) {
        this.f960h.f = i2;
    }

    public final void r(PopupWindow.OnDismissListener onDismissListener) {
        this.f963k = (w) onDismissListener;
    }

    public final void s(boolean z2) {
        this.f972t = z2;
    }

    public final void t(int i2) {
        this.f960h.k(i2);
    }

    public final void l(n nVar) {
    }
}
