package h;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import e.C0019g;

public final class o implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, y {

    /* renamed from: a  reason: collision with root package name */
    public F f1053a;
    public C0019g b;

    /* renamed from: c  reason: collision with root package name */
    public j f1054c;

    public final void b(n nVar, boolean z2) {
        C0019g gVar;
        if ((z2 || nVar == this.f1053a) && (gVar = this.b) != null) {
            gVar.dismiss();
        }
    }

    public final boolean m(n nVar) {
        return false;
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        j jVar = this.f1054c;
        if (jVar.f == null) {
            jVar.f = new i(jVar);
        }
        this.f1053a.q(jVar.f.getItem(i2), (z) null, 0);
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        this.f1054c.b(this.f1053a, true);
    }

    public final boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        F f = this.f1053a;
        if (i2 == 82 || i2 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.b.getWindow();
                if (!(window2 == null || (decorView2 = window2.getDecorView()) == null || (keyDispatcherState2 = decorView2.getKeyDispatcherState()) == null)) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.b.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                f.c(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return f.performShortcut(i2, keyEvent, 0);
    }
}
