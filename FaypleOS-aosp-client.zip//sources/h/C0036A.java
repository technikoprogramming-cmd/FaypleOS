package h;

/* renamed from: h.A  reason: case insensitive filesystem */
public interface C0036A {
    void c(p pVar);

    p getItemData();
}
