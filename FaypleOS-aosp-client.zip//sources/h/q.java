package h;

import C.j;
import android.view.ActionProvider;

public final class q implements ActionProvider.VisibilityListener {

    /* renamed from: a  reason: collision with root package name */
    public j f1082a;
    public final ActionProvider b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ u f1083c;

    public q(u uVar, ActionProvider actionProvider) {
        this.f1083c = uVar;
        this.b = actionProvider;
    }

    public final void onActionProviderVisibilityChanged(boolean z2) {
        j jVar = this.f1082a;
        if (jVar != null) {
            n nVar = ((p) jVar.b).f1069n;
            nVar.f1036h = true;
            nVar.p(true);
        }
    }
}
