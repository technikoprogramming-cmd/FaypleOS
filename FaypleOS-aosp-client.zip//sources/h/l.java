package h;

import android.view.MenuItem;

public interface l {
    void g(n nVar);

    boolean h(n nVar, MenuItem menuItem);
}
