package h;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import androidx.appcompat.view.menu.ExpandedMenuView;
import e.C0014b;
import e.C0018f;
import e.C0019g;

public final class j implements z, AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public Context f1022a;
    public LayoutInflater b;

    /* renamed from: c  reason: collision with root package name */
    public n f1023c;

    /* renamed from: d  reason: collision with root package name */
    public ExpandedMenuView f1024d;

    /* renamed from: e  reason: collision with root package name */
    public y f1025e;
    public i f;

    public j(ContextWrapper contextWrapper) {
        this.f1022a = contextWrapper;
        this.b = LayoutInflater.from(contextWrapper);
    }

    public final void b(n nVar, boolean z2) {
        y yVar = this.f1025e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    public final void c() {
        i iVar = this.f;
        if (iVar != null) {
            iVar.notifyDataSetChanged();
        }
    }

    public final boolean d(p pVar) {
        return false;
    }

    public final void e(y yVar) {
        throw null;
    }

    public final void g(Context context, n nVar) {
        if (this.f1022a != null) {
            this.f1022a = context;
            if (this.b == null) {
                this.b = LayoutInflater.from(context);
            }
        }
        this.f1023c = nVar;
        i iVar = this.f;
        if (iVar != null) {
            iVar.notifyDataSetChanged();
        }
    }

    public final boolean i() {
        return false;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [android.content.DialogInterface$OnClickListener, h.y, h.o, java.lang.Object, android.content.DialogInterface$OnDismissListener] */
    public final boolean j(F f2) {
        if (!f2.hasVisibleItems()) {
            return false;
        }
        ? obj = new Object();
        obj.f1053a = f2;
        Context context = f2.f1031a;
        C0018f fVar = new C0018f(context);
        C0014b bVar = (C0014b) fVar.b;
        j jVar = new j(bVar.f826a);
        obj.f1054c = jVar;
        jVar.f1025e = obj;
        f2.b(jVar, context);
        j jVar2 = obj.f1054c;
        if (jVar2.f == null) {
            jVar2.f = new i(jVar2);
        }
        bVar.f830g = jVar2.f;
        bVar.f831h = obj;
        View view = f2.f1043o;
        if (view != null) {
            bVar.f829e = view;
        } else {
            bVar.f827c = f2.f1042n;
            bVar.f828d = f2.f1041m;
        }
        bVar.f = obj;
        C0019g a2 = fVar.a();
        obj.b = a2;
        a2.setOnDismissListener(obj);
        WindowManager.LayoutParams attributes = obj.b.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        obj.b.show();
        y yVar = this.f1025e;
        if (yVar == null) {
            return true;
        }
        yVar.m(f2);
        return true;
    }

    public final boolean k(p pVar) {
        return false;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        this.f1023c.q(this.f.getItem(i2), this, 0);
    }
}
