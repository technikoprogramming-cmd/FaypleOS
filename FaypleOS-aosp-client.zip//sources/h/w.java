package h;

import android.widget.PopupWindow;

public final class w implements PopupWindow.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ x f1090a;

    public w(x xVar) {
        this.f1090a = xVar;
    }

    public final void onDismiss() {
        this.f1090a.c();
    }
}
