package h;

import i.L0;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final L0 f996a;
    public final n b;

    /* renamed from: c  reason: collision with root package name */
    public final int f997c;

    public g(L0 l0, n nVar, int i2) {
        this.f996a = l0;
        this.b = nVar;
        this.f997c = i2;
    }
}
