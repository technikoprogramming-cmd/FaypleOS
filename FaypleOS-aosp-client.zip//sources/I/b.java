package I;

import java.util.LinkedHashMap;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public final LinkedHashMap f73a = new LinkedHashMap();
}
