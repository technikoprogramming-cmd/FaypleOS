package I;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final Class f74a;

    public d(Class cls) {
        this.f74a = cls;
    }
}
