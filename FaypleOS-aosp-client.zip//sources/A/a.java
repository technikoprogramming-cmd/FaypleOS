package A;

public abstract class a {
}
